#!/bin/bash
NC='\e[0m'
dateFromServer=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
ipsaya=$(wget -qO- ipinfo.io/ip)
data_server=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
date_list=$(date +"%Y-%m-%d" -d "$data_server")

clear
Repo1="https://raw.githubusercontent.com/bowowiwendi/ipvps/main/ip"
export MYIP=$( curl -s https://ipinfo.io/ip/ )
SELLER=$(curl -sS ${Repo1}ip | grep $MYIP | awk '{print $2}')
Exp=$(curl -sS ${Repo1}ip | grep $MYIP | awk '{print $3}')
data_ip="https://raw.githubusercontent.com/bowowiwendi/ipvps/main/ip"
d2=$(date -d "$date_list" +"+%s")
d1=$(date -d "$Exp" +"+%s")
dayleft=$(( ($d1 - $d2) / 86400 ))

#########################
[[ ! -f /usr/bin/git ]] && apt install git -y &> /dev/null
# COLOR VALIDATION
clear
RED='\033[0;31m'
NC='\e[0m'
gray="\e[1;30m"
Blue="\033[1;36m"
GREEN='\033[0;32m'
grenbo="\033[1;95m"
YELL='\033[1;33m'
BGX="\033[42m"
END='\e[0m'
AKTIF="VERIFIED"
REPO="https://github.com/bowowiwendi/ipvps.git"
REPO2="https://raw.githubusercontent.com/bowowiwendi/ipvps/main/ip"
EMAIL="bowowiwendi@gmail.com"
USER="bowowiwendi"

TIMES="10"
CHATID=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 3)
KEY=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 2)
URL="https://api.telegram.org/bot$KEY/sendMessage"


    today=$(date -d "0 days" +"%Y-%m-%d")  # Perbaikan penugasan variabel today
    mkdir /root/ipvps
    touch /root/ipvps/ip
    wget -q -O /root/ipvps/ip "${REPO2}" &> /dev/null || { echo "Failed to download IP list"; exit 1; }  # Penanganan kesalahan
    clear
    echo -e ""
    echo -e ""
    read -p "  Input IP Address : " ip
    # Validasi format IP
    if ! [[ $ip =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
        echo "Format IP tidak valid!"
        exit 1
    fi
    CLIENT_EXISTS=$(grep -w $ip /root/ipvps/ip | wc -l)
    if [[ ${CLIENT_EXISTS} == '1' ]]; then  # Memastikan if memiliki pasangan fi
        echo "IP Already Exist !"
        exit 0
    fi  # Perbaikan: menambahkan fi yang hilang
    echo -e ""
    read -p "  Input Username IP (Example : Wendy) : " name
    # Validasi username
    if [[ -z "$name" ]]; then
        echo "Username tidak boleh kosong!"
        exit 1
    fi
    #name=H6EFctYeZ3DqOWSaiXjtT1u8`</dev/urandom tr -dc A-Z0-9 | head -c4`
    read -p "Input Expired Days : " exp11
    if ! [[ "$exp11" =~ ^[0-9]+$ ]]; then  # Memeriksa apakah input bukan angka
        exp2="lifetime"  # Menetapkan masa aktif sebagai lifetime
    else
        exp2=$(date -d "$exp11 days" +"%Y-%m-%d")  # Perbaikan penugasan variabel exp2
    fi
    echo "### ${name} ${exp2} ${ip}" >> /root/ipvps/ip
    fi  # Menambahkan fi yang hilang di sini
    cd /root/ipvps
    git config --global user.email "${EMAIL}" &> /dev/null
    git config --global user.name "${USER}" &> /dev/null
    rm -rf .git &> /dev/null
    git init &> /dev/null
    git add . &> /dev/null
    git commit -m "update file" &> /dev/null
    git branch -M main &> /dev/null
    git remote add origin git@github.com:bowowiwendi/ipvps.git
    git push -f origin main &> /dev/null
    rm -rf /root/ipvps
    clear
    sleep 1
    echo "  Registering IP Address..."
    sleep 1
    echo "  Processing..."
    sleep 1
    echo "  Done!"
    sleep 1
    clear
TEXT="
<code>───────────────────────────</code>
<code> SUCCES  REGISTERED IP VPS </code>
<code>───────────────────────────</code>
<code>USERNAME       : $name</code>
<code>IP Address     : $ip</code>
<code>Registered On  : $today</code>
<code>Expired On     : $exp2</code>
<code>───────────────────────────</code>
AUTOSCRIPT VPS
UP REPO DEBIAN 10
<code>apt update -y && apt upgrade -y && apt dist-upgrade -y && reboot</code>
UP REPO UBUNTU 20
<code>apt update && apt upgrade -y && update-grub && sleep 2 && reboot</code>
INSTALL SCRIPT
<code>apt install -y && apt update -y && apt upgrade -y && apt install lolcat -y && gem install lolcat && wget -q https://raw.githubusercontent.com/bowowiwendi/WendyVpn/ABSTRAK/setup-main.sh && chmod +x setup-main.sh && ./setup-main.sh</code>
PERINTAH UPDATE
<code>wget https://raw.githubusercontent.com/bowowiwendi/WendyVpn/ABSTRAK/files/update.sh && chmod +x update.sh && ./update.sh</code>
"
curl -s --max-time $TIMES -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL >/dev/null