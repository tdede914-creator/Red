#!/bin/bash
# //====================================================
# //	System Request:Debian 9+/Ubuntu 18.04+/20+
# //	Author:	bhoikfostyahya
# //	Dscription: Xray Menu Management
# //	email: admin@bhoikfostyahya.com
# //  telegram: https://t.me/bhoikfost_yahya
# //====================================================
# // font color configuration | BHOIKFOST YAHYA AUTOSCRIPT
red() { echo -e "\\033[32;1m${*}\\033[0m"; }
red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
plain='\033[0m'
blue='\033[0;34m'
ungu='\033[0;35m'
Green="\033[32m"
Red="\033[31m"
WhiteB="\e[5;37m"
BlueCyan="\e[5;36m"
MYIP=$(wget -qO- ipv4.icanhazip.com)
Green_background="\033[42;37m"
Red_background="\033[41;37m"
Suffix="\033[0m"
echo -e "◇━━━━━━━━━━━━━━━━━◇"
marimakan=($(grep '^###' /etc/xray/config.json | cut -d ' ' -f 2 | sort | uniq))
echo -n > /tmp/rotate
for user in ${marimakan[@]}; do
ehh=$(cat /var/log/xray/access.log | grep "$user" | cut -d " " -f 3 | sed 's/tcp://g' | cut -d ":" -f 1 | sort | uniq);
echo -e "Account   : $user"
echo -e "IP Login  : $ehh"
echo -e "◇━━━━━━━━━━━━━━━━━◇"
