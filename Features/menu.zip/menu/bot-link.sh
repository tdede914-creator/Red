#!/bin/bash
function send_log(){
    # Bot pertama
    CHATID1=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 3)
    KEY1=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 2)
    TIME="10"
    TEXT="
<code>◇━━━━━━━━━━━━━━━━━━━━━━◇</code>
        <b>📦SUCCESSFULL GENERATE LINK BACKUP 📦</b>
<code>◇━━━━━━━━━━━━━━━━━━━━━━◇</code>
<b>LINK BACKUP :</b> 🔗 $link
<code>◇━━━━━━━━━━━━━━━━━━━━━━◇</code>
"
    # Kirim ke bot pertama
    URL1="https://api.telegram.org/bot$KEY1/sendMessage"
    curl -s --max-time $TIME -d "chat_id=$CHATID1&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL1 >/dev/null
}
clear
echo -e ""
echo -e "\033[96;1m============================\033[0m"
echo -e "\033[93;1m  INPUT IP DAN TANGGAL"
echo -e "\033[96;1m============================\033[0m"
echo -e "\033[91;1m contoh IP-YYYY-MM-DD :\033[0m123.123.123.123-2050-01-31\033[93\033[0m"
read -p "IP-YYYY-MM-DD :  " iptanggal
echo -e ""
url=$(rclone link del:backup/WT-${iptanggal}.zip) 
id=(`echo $url | grep '^https' | cut -d'=' -f2`)
link="https://drive.google.com/u/4/uc?id=${id}&export=download"
clear
send_log
echo -e "
==================================
SUCCESSFULL GENERATE LINK BACKUP
==================================
LINK BACKUP : $link
==================================
"
echo "Silahkan copy Link dan restore di VPS baru"
echo ""