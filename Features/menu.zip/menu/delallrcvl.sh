sed -i '/^#&/d' /etc/xray/.recovery.db
sed -i '/^#&&/d' /etc/xray/.recovery.db