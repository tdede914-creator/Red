 sed -i "/^### $user $exp/,/^},{/d" /etc/vmess/.vmess.db
 sed -i "/^### $user $exp/,/^},{/d" /etc/vless/.vless.db
 sed -i "/^### $user $exp/,/^},{/d" /etc/trojan/.trojan.db
 sed -i "/^### $user $exp/,/^},{/d" /etc/shadowsocks/.shadowsocks.db