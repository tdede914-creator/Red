#!/bin/bash
    echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
    echo -e "          Hapus Akun Trojan            "
    echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
    echo "  User       Expired  " 
	echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
	grep -E "^#! " "/etc/xray/.recovery.db" | cut -d ' ' -f 2-3 | column -t | sort | uniq
    echo ""
    echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
	read -rp "Ketik Usernamenya : " user
    if [ -z $user ]; then
    menu
    else
    exp=$(grep -wE "^#! $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
    sed -i "/^#! $user $exp/,/^},{/d" /etc/xray/.recovery.db
    sed -i "/^#!& $user $exp/,/^},{/d" /etc/xray/.recovery.db
    sed -i "/^#! $user $exp/,/^},{/d" /etc/trojan/.trojan.db
    systemctl restart xray > /dev/null 2>&1