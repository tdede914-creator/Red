#!/bin/bash
# // lock
function lockws(){
NUMBER_OF_CLIENTS=$(grep -c -E "^### " "/etc/xray/config.json")
	if [[ ${NUMBER_OF_CLIENTS} == '0' ]]; then
		clear
        echo -e "\033[1;93m┌──────────────────────────────────────────┐\033[0m"
        echo -e "           Kunci Vmess  "|lolcat
        echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
		echo ""
		echo "You have no existing clients!"
		echo ""
		echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
        echo ""
        read -n 1 -s -r -p "Press any key to back on menu"
        m-vmess
	fi

	clear
	echo -e "\033[1;93m┌──────────────────────────────────────────┐\033[0m"
    echo -e "              Kunci Vmess    "|lolcat
    echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
    echo ""
  	grep -E "^### " "/etc/xray/config.json" | cut -d ' ' -f 2-3 | column -t | sort | uniq
    echo ""
    echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
	read -rp "Input Username : " user
    if [ -z $user ]; then
    m-vmess
    else
iplimit=$(grep -E "^### " "/etc/vmess/.vmess.db" | cut -d ' ' -f 6 | sed -n "${CLIENT_NUMBER}"p)
uuid=$(grep -E "^### " "/etc/vmess/.vmess.db" | cut -d ' ' -f 4 | sed -n "${CLIENT_NUMBER}"p)
Quota=$(grep -E "^### " "/etc/vmess/.vmess.db" | cut -d ' ' -f 5 | sed -n "${CLIENT_NUMBER}"p)
exp=$(grep -E "^### " "/etc/vmess/.vmess.db" | cut -d ' ' -f 3 | sed -n "${CLIENT_NUMBER}"p)
sed -i '/#vmess$/a\###! LOCK '"$user $exp"'\
},{"id": "'""$uuid""'","alterId": '"0"',"email": "'""$user""'"' /etc/xray/config.json
echo "###! LOCK ${user} ${exp} ${uuid} ${Quota} ${iplimit}" >>/etc/.vmess.db
    systemctl restart xray > /dev/null 2>&1
    clear
    echo -e "\033[1;93m┌──────────────────────────────────────────┐\033[0m"
    echo " VMESS Account Was Successfully Lock"|lolcat
    echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
    echo ""
    echo " Client Name  : $user lock"
    echo ""
    echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
    echo ""
    read -n 1 -s -r -p "Press any key to back on menu"
    m-vmess
    fi
}
function unlockws(){
NUMBER_OF_CLIENTS=$(grep -c -E "^###! " "/etc/xray/config.json")
	if [[ ${NUMBER_OF_CLIENTS} == '0' ]]; then
		clear
        echo -e "\033[1;93m┌──────────────────────────────────────────┐\033[0m"
        echo -e "          Buka Kunci Vmess  "|lolcat
        echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
		echo ""
		echo "You have no existing clients!"
		echo ""
		echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
        echo ""
        read -n 1 -s -r -p "Press any key to back on menu"
        m-vmess
	fi

	clear
	echo -e "\033[1;93m┌──────────────────────────────────────────┐\033[0m"
    echo -e "             Buka  Kunci Vmess    "|lolcat
    echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
    echo ""
  	grep -E "^###! " "/etc/xray/config.json" | cut -d ' ' -f 2-3 | column -t | sort | uniq
    echo ""
    echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
	read -rp "Input Username : " user
    if [ -z $user ]; then
    m-vmess
    else
iplimit=$(grep -E "^### " "/etc/vmess/.recovery.db" | cut -d ' ' -f 6 | sed -n "${CLIENT_NUMBER}"p)
uuid=$(grep -E "^### " "/etc/vmess/.recovery.db" | cut -d ' ' -f 4 | sed -n "${CLIENT_NUMBER}"p)
Quota=$(grep -E "^### " "/etc/vmess/.recovery.db" | cut -d ' ' -f 5 | sed -n "${CLIENT_NUMBER}"p)
exp=$(grep -E "^### " "/etc/vmess/.recovery.db" | cut -d ' ' -f 3 | sed -n "${CLIENT_NUMBER}"p)
sed -i '/#vmess$/a\### '"$user $exp"'\
},{"id": "'""$uuid""'","alterId": '"0"',"email": "'""$user""'"' /etc/xray/config.json
echo "### ${user} ${exp} ${uuid} ${Quota} ${iplimit}" >>/etc/vmess/.vmess.db    
    systemctl restart xray > /dev/null 2>&1
    clear
    echo -e "\033[1;93m┌──────────────────────────────────────────┐\033[0m"
    echo " VMESS Account Was Successfully unLock"|lolcat
    echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
    echo ""
    echo " Client Name  : $user unlock"
    echo ""
    echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
    echo ""
    read -n 1 -s -r -p "Press any key to back on menu"
    m-vmess
    fi
}
clear
echo -e "\033[1;93m┌──────────────────────────────────────────┐\033[0m"
echo -e "  $NC        MENU LOCK N UNLOCK    $NC" |lolcat
echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
echo -e "\033[1;93m┌──────────────────────────────────────────┐\033[0m"
echo -e "\033[1;93m│  ${grenbo}1.${NC} LOCK${NC}" 
echo -e "\033[1;93m│  ${grenbo}2.${NC} UNLOCK${NC}"
echo -e "\033[1;93m│  ${grenbo}x.${NC} ComeBack${NC}"
echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
echo -e ""
read -p "Select options >>    " menu
echo -e ""
case $menu in
1)
    lockws
    ;;
2)
    unlockws
    ;;
 *)
   m-vmess
   ;;
esac