#!/bin/bash

#IZIN SCRIPT
MYIP=$(curl -sS ipv4.icanhazip.com)
echo -e "\e[32mloading...\e[0m"
clear
# // Domain
domain=$(cat /etc/xray/domain)
CHATID=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 3)
KEY=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 2)
export TIME="1"
export URL="https://api.telegram.org/bot$KEY/sendMessage"


# // USER - SSH
function user-ssh(){
clear
NUMBER_OF_CLIENTS=$(grep -c -E "#ssh# " "/etc/ssh/.ssh.db")
        if [[ ${NUMBER_OF_CLIENTS} == '0' ]]; then
  echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
  echo -e "\e[1;97;101m           CONFIG SSH ACCOUNT           \E[0m"
  echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
                echo ""
                echo "You have no existing clients!"
                clear
                exit 1
        fi

  echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
  echo -e "\e[1;97;101m           CONFIG SSH ACCOUNT           \E[0m"
  echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        echo "     No  USER   PASSWD"
        grep -E "#ssh# " "/etc/ssh/.ssh.db" | cut -d ' ' -f 2-3 | nl -s ') '
        until [[ ${CLIENT_NUMBER} -ge 1 && ${CLIENT_NUMBER} -le ${NUMBER_OF_CLIENTS} ]]; do
                if [[ ${CLIENT_NUMBER} == '1' ]]; then
                        read -rp "Select one client [1]: " CLIENT_NUMBER
                else
                        read -rp "Select one client [1-${NUMBER_OF_CLIENTS}]: " CLIENT_NUMBER
                fi
        done
user=$(grep -E "#ssh# " "/etc/ssh/.ssh.db" | cut -d ' ' -f 2 | sed -n "${CLIENT_NUMBER}"p)
domain=$(cat /etc/xray/domain)
Pass=$(grep -E "#ssh#" "/etc/ssh/.ssh.db" | cut -d ' ' -f 3 | sed -n "${CLIENT_NUMBER}"p)
Quota=$(grep -E "#ssh#" "/etc/ssh/.ssh.db" | cut -d ' ' -f 4 | sed -n "${CLIENT_NUMBER}"p)
iplimit=$(grep -E "#ssh#" "/etc/ssh/.ssh.db" | cut -d ' ' -f 5 | sed -n "${CLIENT_NUMBER}"p)
exp=$(grep -E "#ssh#" "/etc/ssh/.ssh.db" | cut -d ' ' -f 6 | sed -n "${CLIENT_NUMBER}"p)
hariini=`date -d "0 days" +"%Y-%m-%d"`
IP=$(curl -sS ipv4.icanhazip.com)
CITY=$(cat /etc/xray/city)
PUB=$(cat /etc/slowdns/server.pub)
NS=$(cat /root/scdomain)
ISP=$(cat /etc/xray/isp)

cat > /var/www/html/ssh-$Login.txt <<-END
---------------------------------------------------
Format SSH OVPN Account
---------------------------------------------------
Username         : $user
Password         : $Pass
---------------------------------------------------
IP               : $IP
Host             : $domain
Port OpenSSH     : 443, 80, 22
Port Dropbear    : 443, 109
Port Dropbear WS : 443, 109
Port SSH UDP     : 1-65535
Port SSH WS      : 80, 8080, 8081-9999
Port SSH SSL WS  : 443
Port SSL/TLS     : 400-900
Port OVPN WS SSL : 443
Port OVPN SSL    : 443
Port OVPN TCP    : 1194
Port OVPN UDP    : 2200
BadVPN UDP       : 7100, 7300, 7300
---------------------------------------------------
Aktif Selama     : $masaaktif Hari
Dibuat Pada      : $tnggl
Berakhir Pada    : $exp
---------------------------------------------------
Payload WSS: GET wss://BUG.COM/ HTTP/1.1[crlf]Host: $domain[crlf]Upgrade: websocket[crlf][crlf] 
---------------------------------------------------
OVPN Download : https://$domain:81/
---------------------------------------------------

END

CHATID="$CHATID"
KEY="$KEY"
TIME="$TIME"
URL="$URL"
TEXT="
<code>---------------------------------------------------</code>
<code>SSH OVPN Account     </code>
<code>---------------------------------------------------</code>
<code>Username         : </code> <code>$user</code>
<code>Password         : </code> <code>$Pass</code>
<code>Limit Quota      : </code> <code>$Quota</code>
<code>---------------------------------------------------</code>
<code>IP               : $IP</code>
<code>Host             : </code> <code>$domain</code>
<code>Port OpenSSH     : 443, 80, 22</code>
<code>Port Dropbear    : 443, 109</code>
<code>Port SSH WS      : 80, 8080, 8081-9999 </code>
<code>Port SSH UDP     : 1-65535 </code>
<code>Port SSH SSL WS  : 443</code>
<code>Port SSL/TLS     : 400-900</code>
<code>Port OVPN WS SSL : 443</code>
<code>Port OVPN SSL    : 443</code>
<code>Port OVPN TCP    : 443, 1194</code>
<code>Port OVPN UDP    : 2200</code>
<code>BadVPN UDP       : 7100, 7300, 7300</code>
<code>---------------------------------------------------</code>
<code>Payload WSS      : </code><code>GET wss://BUG.COM/ HTTP/1.1[crlf]Host: $domain[crlf]Upgrade: websocket[crlf][crlf]</code>
<code>---------------------------------------------------</code>
OVPN Download : https://$domain:81/
<code>---------------------------------------------------</code>
<code>Save Link Account: </code>https://$domain:81/ssh-$user.txt
<code>---------------------------------------------------</code>
Aktif Selama         : $masaaktif Hari
Dibuat Pada          : $tnggl
Berakhir Pada        : $exp
<code>---------------------------------------------------</code>
"
curl -s --max-time $TIME -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL >/dev/null
clear
echo ""
echo -e "\033[1;93m---------------------------------------------------\033[0m"
echo -e "                SSH OVPN / UDP "
echo -e "\033[1;93m---------------------------------------------------\033[0m"
echo -e "Username         : $user"
echo -e "Password         : $Pass"
echo -e "Limit Quota      : $Quota GB"
echo -e "Limit Ip         : ${iplimit} User"
echo -e "Host             : $domain"
echo -e "Host Slowdns     : ${NS}"
echo -e "Pub Key          : ${PUB}"
echo -e "Location         : $CITY"
echo -e "ISP              : $ISP"
echo -e "Port OpenSSH     : 443, 80, 22"
echo -e "Port DNS         : 443, 53 ,22 "
echo -e "Port SSH UDP     : 1-65535"
echo -e "Port Dropbear    : 443, 109 ,143"
echo -e "Port SSH WS      : 80,8080,8880,2086,2095,2082"
echo -e "Port SSH SSL WS  : 443"
echo -e "Port SSL/TLS     : 443"
echo -e "Port OVPN WS SSL : 443"
echo -e "Port OVPN SSL    : 443"
echo -e "Port OVPN TCP    : 443, 1194"
echo -e "Port OVPN UDP    : 2200"
echo -e "BadVPN UDP       : 7100, 7300, 7300"
echo -e "\033[1;93m---------------------------------------------------\033[0m"
echo -e "Port 80          : $domain:80@$user:$Pass"
echo -e "Port 443         : $domain:443@$user:$Pass"
echo -e "Udp Custom       : $domain:1-65535@$user:$Pass"
echo -e "\033[1;93m---------------------------------------------------\033[0m"
echo -e "PAYLOAD NONE TLS     :" 
echo -e "GET / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]"
echo -e "\033[1;93m---------------------------------------------------\033[0m"
echo -e "PAYLOAD TLS       :" 
echo -e "GET wss://[host]/ HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]"
echo -e "\033[1;93m---------------------------------------------------\033[0m"
echo -e "OVPN Download    : https://$domain:81/"
echo -e "\033[1;93m---------------------------------------------------\033[0m"
echo -e "Save Link Account: https://$domain:81/ssh-$user.txt"
echo -e "\033[1;93m---------------------------------------------------\033[0m"
#echo -e "Aktif Selama     : $masaaktif Hari"
#echo -e "Dibuat Pada      : $tnggl"
echo -e "Berakhir Pada    : $exp"
echo -e "\033[1;93m---------------------------------------------------\033[0m"
echo -e ""
read -p "press !! [ ENTER ] To menu"
m-sshws
}



# // ADD - SSH
function addssh(){
CHATID=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 3)
KEY=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 2)
export TIME="1"
export URL="https://api.telegram.org/bot$KEY/sendMessage"
clear
#IZIN SCRIPT
MYIP=$(curl -sS ipv4.icanhazip.com)
clear
export TIME="10"
IP=$(curl -sS ipv4.icanhazip.com)
ISP=$(cat /etc/xray/isp)
CITY=$(cat /etc/xray/city)
domain=$(cat /etc/xray/domain)
NS=$(cat /root/domain)
clear
  echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
  echo -e "\033[1;96m          CREATE TITLE SSH/OVPN/UDP         \033[0m"
  echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
  echo -e ""
read -p " USERNAME      : " Login
read -p " PASSWORD      : " Pass
read -p " IP LIMIT      : " iplimit
read -p " QUOTA (GB)    : " Quota
read -p " EXPIRED (DAY) : " masaaktif
#limitip
if [[ $iplimit -gt 0 ]]; then
mkdir -p /etc/kyt/limit/ssh/ip
echo -e "$iplimit" > /etc/kyt/limit/ssh/ip/$Login
else
echo > /dev/null
fi
clear
tgl=$(date -d "$masaaktif days" +"%d")
bln=$(date -d "$masaaktif days" +"%b")
thn=$(date -d "$masaaktif days" +"%Y")
expe="$tgl $bln, $thn"
tgl2=$(date +"%d")
bln2=$(date +"%b")
thn2=$(date +"%Y")
tnggl="$tgl2 $bln2, $thn2"
useradd -e `date -d "$masaaktif days" +"%Y-%m-%d"` -s /bin/false -M $Login
expi="$(chage -l $Login | grep "Account expires" | awk -F": " '{print $2}')"
echo -e "$Pass\n$Pass\n"|passwd $Login &> /dev/null
hariini=`date -d "0 days" +"%Y-%m-%d"`
expayer=`date -d "$masaaktif days" +"%Y-%m-%d"`
PUB=$(cat /etc/slowdns/server.pub)

if [ ! -e /etc/ssh ]; then
  mkdir -p /etc/ssh
fi
if [ -z ${Quota} ]; then
  Quota="0"
fi
c=$(echo "${Quota}" | sed 's/[^0-9]*//g')
d=$((${c} * 1024 * 1024 * 1024))
if [[ ${c} != "0" ]]; then
  echo "${d}" >/etc/ssh/${Login}
fi
DATADB=$(cat /etc/ssh/.ssh.db | grep "^#ssh#" | grep -w "${Login}" | awk '{print $2}')
if [[ "${DATADB}" != '' ]]; then
  sed -i "/\b${Login}\b/d" /etc/ssh/.ssh.db
fi
echo "#ssh# ${Login} ${Pass} ${Quota} ${iplimit} ${expe}" >>/etc/ssh/.ssh.db
clear

cat > /var/www/html/ssh-$Login.txt <<-END
---------------------------------------------------
Format SSH OVPN Account
---------------------------------------------------
Username         : $Login
Password         : $Pass
---------------------------------------------------
IP               : $IP
Host             : $domain
Port OpenSSH     : 443, 80, 22
Port Dropbear    : 443, 109
Port Dropbear WS : 443, 109
Port SSH UDP     : 1-65535
Port SSH WS      : 80, 8080, 8081-9999
Port SSH SSL WS  : 443
Port SSL/TLS     : 400-900
Port OVPN WS SSL : 443
Port OVPN SSL    : 443
Port OVPN TCP    : 1194
Port OVPN UDP    : 2200
BadVPN UDP       : 7100, 7300, 7300
---------------------------------------------------
Aktif Selama     : $masaaktif Hari
Dibuat Pada      : $tnggl
Berakhir Pada    : $expe
---------------------------------------------------
Payload WSS: GET wss://BUG.COM/ HTTP/1.1[crlf]Host: $domain[crlf]Upgrade: websocket[crlf][crlf] 
---------------------------------------------------
OVPN Download : https://$domain:81/
---------------------------------------------------

END

CHATID="$CHATID"
KEY="$KEY"
TIME="$TIME"
URL="$URL"
TEXT="
<code>---------------------------------------------------</code>
<code>SSH OVPN Account     </code>
<code>---------------------------------------------------</code>
<code>Username         : </code> <code>$Login</code>
<code>Password         : </code> <code>$Pass</code>
<code>Limit Quota      : </code> <code>$Quota</code>
<code>---------------------------------------------------</code>
<code>IP               : $IP</code>
<code>Host             : </code> <code>$domain</code>
<code>Port OpenSSH     : 443, 80, 22</code>
<code>Port Dropbear    : 443, 109</code>
<code>Port SSH WS      : 80, 8080, 8081-9999 </code>
<code>Port SSH UDP     : 1-65535 </code>
<code>Port SSH SSL WS  : 443</code>
<code>Port SSL/TLS     : 400-900</code>
<code>Port OVPN WS SSL : 443</code>
<code>Port OVPN SSL    : 443</code>
<code>Port OVPN TCP    : 443, 1194</code>
<code>Port OVPN UDP    : 2200</code>
<code>BadVPN UDP       : 7100, 7300, 7300</code>
<code>---------------------------------------------------</code>
<code>Payload WSS      : </code><code>GET wss://BUG.COM/ HTTP/1.1[crlf]Host: $domain[crlf]Upgrade: websocket[crlf][crlf]</code>
<code>---------------------------------------------------</code>
OVPN Download : https://$domain:81/
<code>---------------------------------------------------</code>
<code>Save Link Account: </code>https://$domain:81/ssh-$Login.txt
<code>---------------------------------------------------</code>
Aktif Selama         : $masaaktif Hari
Dibuat Pada          : $tnggl
Berakhir Pada        : $expe
<code>---------------------------------------------------</code>
"

curl -s --max-time $TIME -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL >/dev/null
clear
echo ""
echo -e "\033[1;93m---------------------------------------------------\033[0m"
echo -e "                SSH OVPN / UDP "
echo -e "\033[1;93m---------------------------------------------------\033[0m"
echo -e "Username         : $Login"
echo -e "Password         : $Pass"
echo -e "Limit Quota      : $Quota GB"
echo -e "Limit Ip         : ${iplimit} User"
echo -e "Host             : $domain"
echo -e "Host Slowdns     : ${NS}"
echo -e "Pub Key          : ${PUB}"
echo -e "Location         : $CITY"
echo -e "ISP              : $ISP"
echo -e "Port OpenSSH     : 443, 80, 22"
echo -e "Port DNS         : 443, 53 ,22 "
echo -e "Port SSH UDP     : 1-65535"
echo -e "Port Dropbear    : 443, 109 ,143"
echo -e "Port SSH WS      : 80,8080,8880,2086,2095,2082"
echo -e "Port SSH SSL WS  : 443"
echo -e "Port SSL/TLS     : 443"
echo -e "Port OVPN WS SSL : 443"
echo -e "Port OVPN SSL    : 443"
echo -e "Port OVPN TCP    : 443, 1194"
echo -e "Port OVPN UDP    : 2200"
echo -e "BadVPN UDP       : 7100, 7300, 7300"
echo -e "\033[1;93m---------------------------------------------------\033[0m"
echo -e "Port 80          : $domain:80@$Login:$Pass"
echo -e "Port 443         : $domain:443@$Login:$Pass"
echo -e "Udp Custom       : $domain:1-65535@$Login:$Pass"
echo -e "\033[1;93m---------------------------------------------------\033[0m"
echo -e "PAYLOAD NONE TLS     :" 
echo -e "GET / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]"
echo -e "\033[1;93m---------------------------------------------------\033[0m"
echo -e "PAYLOAD TLS       :" 
echo -e "GET wss://[host]/ HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]"
echo -e "\033[1;93m---------------------------------------------------\033[0m"
echo -e "OVPN Download    : https://$domain:81/"
echo -e "\033[1;93m---------------------------------------------------\033[0m"
echo -e "Save Link Account: https://$domain:81/ssh-$Login.txt"
echo -e "\033[1;93m---------------------------------------------------\033[0m"
echo -e "Aktif Selama     : $masaaktif Hari"
echo -e "Dibuat Pada      : $tnggl"
echo -e "Berakhir Pada    : $expe"
echo -e "\033[1;93m---------------------------------------------------\033[0m"
echo -e ""
read -p "press !! [ ENTER ] To menu"
m-sshws

clear
echo ""
echo -e "\033[1;93m====================\033[0m"
echo -e " SSH OVPN Account    "
echo -e "\033[1;93m====================\033[0m"
echo -e "Username         : $user"
echo -e "Password         : $Pass"
echo -e "Host             : $domain"
echo -e "Host Slowdns     : ${NS}"
echo -e "Pub Key          : ${PUB}"
echo -e "Limit IP         : ${iplim} IP"
echo -e "Location         : $CITY"
echo -e "Port OpenSSH     : 443, 80, 22"
echo -e "Port DNS         : 443, 53 ,22 "
echo -e "Port SSH UDP     : 1-65535"
echo -e "Port Dropbear    : 443, 109"
echo -e "Port SSH WS      : 80,8080,8880,2086"
echo -e "Port SSH SSL WS  : 443"
echo -e "Port SSL/TLS     : 442,443,444,777"
echo -e "Port OVPN WS SSL : 443"
echo -e "Port OVPN SSL    : 443"
echo -e "Port OVPN TCP    : 443, 1194"
echo -e "Port OVPN UDP    : 2200"
echo -e "BadVPN UDP       : 7100, 7300, 7300"
echo -e "\033[1;93m====================\033[0m"
echo -e "Tinggal Copy Port 80  : ${domain}:80@$user:${Pass}"
echo -e "Tinggal Copy Port 443 : ${domain}:443@$user:${Pass}"
echo -e "\033[1;93m====================\033[0m"
echo -e " UDP Account  : ${domain}:1-65535@$user:${Pass}"
echo -e "\033[1;93m====================\033[0m"
echo -e "Ovpn Download : https://$domain:81/"
echo -e "\033[1;93m====================\033[0m"
echo -e "Payload WSS   : GET wss://BUG.COM/ HTTP/1.1[crlf]Host: $domain[crlf]Upgrade: websocket[crlf][crlf]"
echo -e "\033[1;93m====================\033[0m"
echo -e "Link Txt : https://${domain}:81/ssh-$user.txt"
echo -e "\033[1;93m====================\033[0m"
echo -e "Aktif Selama   : $masaaktif Hari"
echo -e "Dibuat Pada    : $tnggl"
echo -e "Berakhir Pada  : $exp"
echo -e "\033[1;93m====================\033[0m"
echo -e ""
read -n 1 -s -r -p "Press any key to back on menu"
m-sshws
}



# // TRIALL
function trial(){
IP=$(curl -sS ipv4.icanhazip.com)
Login=WV-`</dev/urandom tr -dc X-Z0-9 | head -c4`
hari="1"
Pass=1
iplimit=4
ISP=$(cat /etc/xray/isp)
CITY=$(cat /etc/xray/city)
PUB=$(cat /etc/slowdns/server.pub)
NS=$(cat /root/domain)
clear
# // MASA AKTIF
tgl=$(date -d "$masaaktif days" +"%d")
bln=$(date -d "$masaaktif days" +"%b")
thn=$(date -d "$masaaktif days" +"%Y")
expe="$tgl $bln, $thn"
tgl2=$(date +"%d")
bln2=$(date +"%b")
thn2=$(date +"%Y")
tnggl="$tgl2 $bln2, $thn2"
useradd -e `date -d "$masaaktif days" +"%Y-%m-%d"` -s /bin/false -M $Login
exp="$(chage -l $Login | grep "Account expires" | awk -F": " '{print $2}')"
hariini=`date -d "0 days" +"%Y-%m-%d"`
expi=`date -d "$masaaktif days" +"%Y-%m-%d"`
echo -e "$Pass\n$Pass\n"|passwd $Login &> /dev/null
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e "\033[96;1m     Set Expired In Minutes           "
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e " "
read -p " MINUTES:   " pup
CHATID="$CHATID"
KEY="$KEY"
TIME="$TIME"
URL="$URL"
TEXT="<code>---------------------------------------------------</code>
<code>Your Premium VPN Details</code>
<code>---------------------------------------------------</code>
<code>IP Address    =</code> <code>$IP</code>
<code>Hostname      =</code> <code>$domain</code>
<code>Username      =</code> <code>$Login</code>
<code>Password      =</code> <code>$Pass</code>
<code>---------------------------------------------------</code>
<code>OpenSSH = 22
Dropbear      = 443, 109, 143
SSL/TLS       = 400-900
SSH WS TLS    = 443
SSH WS NTLS   = 80, 8080, 8081-9999
OVPN WS NTLS  = 80, 8080, 8880
OVPN WS TLS   = 443
BadVPN UDP    = 7100,7200,7300</code>
<code>---------------------------------------------------</code>
Ovpn Download : https://$domain:81/
<code>---------------------------------------------------</code>
Save Link Account: https://$domain:81/ssh-$Login.txt
<code>---------------------------------------------------</code>
Berakhir Pada  : $pup Menit
<code>---------------------------------------------------</code>
"

curl -s --max-time $TIME -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL >/dev/null
echo ""
mkdir -p /etc/ssh

if [[ ${c} != "0" ]]; then
  echo "${d}" >/etc/ssh/${Login}
fi
DATADB=$(cat /etc/ssh/.ssh.db | grep "^###" | grep -w "${Login}" | awk '{print $2}')
if [[ "${DATADB}" != '' ]]; then
  sed -i "/\b${Login}\b/d" /etc/ssh/.ssh.db
fi
echo "### ${Login} " >>/etc/ssh/.ssh.db
echo ""
cat > /var/www/html/ssh-$Login.txt <<-END
---------------------------------------------------
Format SSH OVPN Account
---------------------------------------------------
Username         : $Login
Password         : $Pass
Berakhir Pada    : $pup Menit
---------------------------------------------------
IP               : $IP
Host             : $domain
Port OpenSSH     : 443, 80, 22
Port Dropbear    : 443, 109
Port SSH UDP     : 1-65535
Port SSH WS      : 80, 8080, 8081-9999
Port SSH SSL WS  : 443
Port SSL/TLS     : 400-900
Port OVPN WS SSL : 443
Port OVPN SSL    : 443
Port OVPN TCP    : 1194
Port OVPN UDP    : 2200
BadVPN UDP       : 7100, 7300, 7300
---------------------------------------------------
Payload : GET / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]
---------------------------------------------------
OVPN Download : https://$domain:81/
---------------------------------------------------

END
clear
echo -e "--------------------------------------------------------------"
echo -e "                   Trial SSH OVPN Account    "
echo -e "--------------------------------------------------------------"
echo -e "Username         : $Login"
echo -e "Password         : $Pass"
echo -e "Limit Quota      : $Quota GB"
echo -e "Limit Ip         : ${iplimit} User"
echo -e "Host             : $domain"
echo -e "Host Slowdns     : ${NS}"
echo -e "Pub Key          : ${PUB}"
echo -e "Location         : $CITY"
echo -e "ISP              : $ISP"
echo -e "Port OpenSSH     : 443, 80, 22"
echo -e "Port DNS         : 443, 53 ,22 "
echo -e "Port SSH UDP     : 1-65535"
echo -e "Port Dropbear    : 443, 109"
echo -e "Port SSH WS      : 80,8080,8880,2086,2082"
echo -e "Port SSH SSL WS  : 443,8443"
echo -e "Port SSL/TLS     : 443-900"
echo -e "Port OVPN WS SSL : 443"
echo -e "Port OVPN SSL    : 443"
echo -e "Port OVPN TCP    : 443, 1194"
echo -e "Port OVPN UDP    : 2200"
echo -e "BadVPN UDP       : 7100, 7300, 7300"
echo -e "--------------------------------------------------------------"
echo -e "Port 80         : $domain:80@$Login:$Pass"
echo -e "Port 443        : $domain:443@$Login:$Pass"
echo -e "Udp Custom      : $domain:1-65535@$Login:$Pass"
echo -e "--------------------------------------------------------------"
echo -e "PAYLOAD NONE TLS      :"
echo -e " GET / HTTP/1.1[crlf]Host: $domain[crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]"
echo -e "--------------------------------------------------------------"
echo -e "PAYLOAD WSS TLS        :"
echo -e " GET wss://[host] HTTP/1.1[crlf]Host: $domain[crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]"
echo -e "--------------------------------------------------------------"
echo -e "OVPN Download    : https://$domain:81/"
echo -e "--------------------------------------------------------------"
echo -e "Save Link Account: https://$domain:81/ssh-$Login.txt"
echo -e "--------------------------------------------------------------"
echo -e "Berakhir Pada    : $pup Menit"
echo -e "--------------------------------------------------------------"
echo userdel -f "$Login" | at now + $pup minutes &> /dev/null
echo -e ""
read -p "press !! [ ENTER ] To Menu"
m-sshws
}

# // RENEW SSH
function renewssh(){
MYIP=$(wget -qO- ipinfo.io/ip);
clear
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e "                     List Member SSH                   "
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo    "USERNAME               EXP DATE                STATUS  "
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
while read expired
do
AKUN="$(echo $expired | cut -d: -f1)"
ID="$(echo $expired | grep -v nobody | cut -d: -f3)"
exp="$(chage -l $AKUN | grep "Account expires" | awk -F": " '{print $2}')"
status="$(passwd -S $AKUN | awk '{print $2}' )"
if [[ $ID -ge 1000 ]]; then
if [[ "$status" = "L" ]]; then
printf "%-17s %2s %-17s %2s \n" "$AKUN" "$exp     " "LOCKED"
else
printf "%-17s %2s %-17s %2s \n" "$AKUN" "$exp     " "UNLOCKED"
fi
fi
done < /etc/passwd
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e "           Masukan Usernamenya "
echo -e "\033[1;93m────────────────────────────────────────────\033[0m" 
read -p "Username : " User
egrep "^$User" /etc/passwd >/dev/null
if [ $? -eq 0 ]; then
read -p "Day Extend : " Days
Today=`date +%s`
Days_Detailed=$(( $Days * 86400 ))
Expire_On=$(($Today + $Days_Detailed))
Expiration=$(date -u --date="1970-01-01 $Expire_On sec GMT" +%Y/%m/%d)
Expiration_Display=$(date -u --date="1970-01-01 $Expire_On sec GMT" '+%d %b %Y')
passwd -u $User
usermod -e  $Expiration $User
egrep "^$User" /etc/passwd >/dev/null
echo -e "$Pass\n$Pass\n"|passwd $User &> /dev/null
clear
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e "               Perpanjang Masa Aktif SSH     "
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e ""
echo -e " Username   : $User"
echo -e " Days Added : $Days Days"
echo -e " Expires on : $Expiration_Display"
echo -e ""
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e ""
read -n 1 -s -r -p "Press any key to back"
m-sshws

else
clear
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e "        Perpanjang Masa Aktif SSH          "
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e ""
echo -e "   Username Tidak Ditemukan       "
echo -e ""
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e ""
read -n 1 -s -r -p "Press any key to back"
m-sshws
fi
}

# // DELETE SSH ðŸŸ¢
function delssh(){
clear
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e "               MEMBER SSH        "
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo "USERNAME          EXP DATE          "
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
while read expired
do
AKUN="$(echo $expired | cut -d: -f1)"
ID="$(echo $expired | grep -v nobody | cut -d: -f3)"
exp="$(chage -l $AKUN | grep "Account expires" | awk -F": " '{print $2}')"
status="$(passwd -S $AKUN | awk '{print $2}' )"
if [[ $ID -ge 1000 ]]; then
if [[ "$status" = "L" ]]; then
printf "%-17s %2s %-17s %2s \n" "$AKUN" "$exp     "
else
printf "%-17s %2s %-17s %2s \n" "$AKUN" "$exp     "
fi
fi
done < /etc/passwd
echo -e "${ORANGE}â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”\033[0m"
echo -e "                DELETE SSH       "
echo -e "${ORANGE}â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”\033[0m"
echo ""
read -p "Ketik Usernamenya : " user

if getent passwd $user > /dev/null 2>&1; then
        userdel $user > /dev/null 2>&1
        exp=$(grep -w "^### $user" "/etc/ssh/.ssh.db" | cut -d ' ' -f 3 | sort | uniq)
        sed -i "/^### $user $exp /,/^},{/d" /etc/ssh/.ssh.db
        rm -f /etc/ssh/$user
        rm -f /etc/kyt/limit/ssh/ip/${user}
	    rm -f /var/www/html/ssh-$user.txt
        echo -e "User $user Berhasil Di Hapus Sayang."
else
        echo -e "Failure: User $user Tidak Di Temukan."
fi
read -p "Press enter back To Menu"
m-sshws
}

# // CEKLIM
function ceklim(){
MYIP=$(wget -qO- ipinfo.io/ip);
clear
echo " "
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo " ";
if [ -e "/root/log-limit.txt" ]; then
echo "User Who Violate The Maximum Limit";
echo "Time - Username - Number of Multilogin"
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
cat /root/log-limit.txt
else
echo " No user has committed a violation"
echo " "
echo " or"
echo " "
echo " The user-limit script not been executed."
fi
echo " "
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
read -p " Pres enter back to menu"
m-sshws
}

# // CEK SSH
function cekssh(){
if [ -e "/var/log/auth.log" ]; then
        LOG="/var/log/auth.log";
fi
if [ -e "/var/log/secure" ]; then
        LOG="/var/log/secure";
fi
                
data=( `ps aux | grep -i dropbear | awk '{print $2}'`);
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo "    ID  |  Username  |  IP Address";
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
cat $LOG | grep -i dropbear | grep -i "Password auth succeeded" > /tmp/login-db.txt;
for PID in "${data[@]}"
do
            cat /tmp/login-db.txt | grep "dropbear\[$PID\]" > /tmp/login-db-pid.txt;
            NUM=`cat /tmp/login-db-pid.txt | wc -l`;
            USER=`cat /tmp/login-db-pid.txt | awk '{print $10}'`;
            IP=`cat /tmp/login-db-pid.txt | awk '{print $12}'`;
            if [ $NUM -eq 1 ]; then
                    echo "$PID - $USER - $IP";
                    fi
done
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo " "
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo "    ID  |  Username  |  IP Address";
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
cat $LOG | grep -i sshd | grep -i "Accepted password for" > /tmp/login-db.txt
data=( `ps aux | grep "\[priv\]" | sort -k 72 | awk '{print $2}'`);

for PID in "${data[@]}"
do
            cat /tmp/login-db.txt | grep "sshd\[$PID\]" > /tmp/login-db-pid.txt;
            NUM=`cat /tmp/login-db-pid.txt | wc -l`;
            USER=`cat /tmp/login-db-pid.txt | awk '{print $9}'`;
            IP=`cat /tmp/login-db-pid.txt | awk '{print $11}'`;
            if [ $NUM -eq 1 ]; then
                    echo "$PID - $USER - $IP";
        fi
done
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
if [ -f "/etc/openvpn/server/openvpn-tcp.log" ]; then
echo ""
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo "    Username  |  IP Address  |  Connected";
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
            cat /etc/openvpn/server/openvpn-tcp.log | grep -w "^CLIENT_LIST" | cut -d ',' -f 2,3,8 | sed -e 's/,/      /g' > /tmp/vpn-login-tcp.txt
            cat /tmp/vpn-login-tcp.txt
fi
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"

if [ -f "/etc/openvpn/server/openvpn-udp.log" ]; then
echo " "
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo "    Username  |  IP Address  |  Connected";
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
            cat /etc/openvpn/server/openvpn-udp.log | grep -w "^CLIENT_LIST" | cut -d ',' -f 2,3,8 | sed -e 's/,/      /g' > /tmp/vpn-login-udp.txt
            cat /tmp/vpn-login-udp.txt
fi
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo "";
echo ""
read -p "Back to Menu "
m-sshws
}

# // MEMBER
function member(){
MYIP=$(wget -qO- ipinfo.io/ip);
clear
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e "\033[1;96m   USERNAME         EXP DATE       STATUS   \033[0m"
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
while read expired
do
AKUN="$(echo $expired | cut -d: -f1)"
ID="$(echo $expired | grep -v nobody | cut -d: -f3)"
exp="$(chage -l $AKUN | grep "Account expires" | awk -F": " '{print $2}')"
status="$(passwd -S $AKUN | awk '{print $2}' )"
if [[ $ID -ge 1000 ]]; then
if [[ "$status" = "L" ]]; then
 printf "%-17s %2s %-17s %2s \n" "  $AKUN" "$exp   " "LOCKED${NORMAL}"
else
 printf "%-17s %2s %-17s %2s \n" "  $AKUN" "$exp   " "UNLOCKED${NORMAL}"
fi
fi
done < /etc/passwd
JUMLAH="$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | wc -l)"
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e "\033[1;96m   Account number: $JUMLAH   Account"
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e ""
read -p " press !! [ ENTER ] Back To Menu"
m-sshws
}

# // TENDANG
function tendang(){
MYIP=$(wget -qO- ipinfo.io/ip);
clear    
MAX=1
if [ -e "/var/log/auth.log" ]; then
        OS=1;
        LOG="/var/log/auth.log";
fi
if [ -e "/var/log/secure" ]; then
        OS=2;
        LOG="/var/log/secure";
fi

if [ $OS -eq 1 ]; then
    userdel -f $user
	service ssh restart > /dev/null 2>&1;
fi
if [ $OS -eq 2 ]; then
    userdel -f $user
	service sshd restart > /dev/null 2>&1;
fi
     userdel -f $user
	service dropbear restart > /dev/null 2>&1;
				
if [[ ${1+x} ]]; then
        MAX=$1;
fi
   cat /etc/passwd | grep "/home/" | cut -d":" -f1 > /root/user.txt
   username1=( `cat "/root/user.txt" `);
   i="0";
for user in "${username1[@]}"
do
   username[$i]=`echo $user | sed 's/'\''//g'`;
   jumlah[$i]=0;
   i=$i+1;
done
   cat $LOG | grep -i dropbear | grep -i "Password auth succeeded" > /tmp/log-db.txt
   proc=( `ps aux | grep -i dropbear | awk '{print $2}'`);
for PID in "${proc[@]}"
do
   cat /tmp/log-db.txt | grep "dropbear\[$PID\]" > /tmp/log-db-pid.txt
   NUM=`cat /tmp/log-db-pid.txt | wc -l`;
   USER=`cat /tmp/log-db-pid.txt | awk '{print $10}' | sed 's/'\''//g'`;
   IP=`cat /tmp/log-db-pid.txt | awk '{print $12}'`;
if [ $NUM -eq 1 ]; then
   i=0;
for user1 in "${username[@]}"
do
if [ "$USER" == "$user1" ]; then
   jumlah[$i]=`expr ${jumlah[$i]} + 1`;
   pid[$i]="${pid[$i]} $PID"
fi
i=$i+1;
done
fi
done
   cat $LOG | grep -i sshd | grep -i "Accepted password for" > /tmp/log-db.txt
   data=( `ps aux | grep "\[priv\]" | sort -k 72 | awk '{print $2}'`);
for PID in "${data[@]}"
do
   cat /tmp/log-db.txt | grep "sshd\[$PID\]" > /tmp/log-db-pid.txt;
   NUM=`cat /tmp/log-db-pid.txt | wc -l`;
   USER=`cat /tmp/log-db-pid.txt | awk '{print $9}'`;
   IP=`cat /tmp/log-db-pid.txt | awk '{print $11}'`;
if [ $NUM -eq 1 ]; then
   i=0;
for user1 in "${username[@]}"
do
if [ "$USER" == "$user1" ]; then
   jumlah[$i]=`expr ${jumlah[$i]} + 1`;
   pid[$i]="${pid[$i]} $PID"
fi
   i=$i+1;
done
fi
done
   j="0";
for i in ${!username[*]}
do
if [ ${jumlah[$i]} -gt $MAX ]; then
   date=`date +"%Y-%m-%d %X"`;
   echo "$date - ${username[$i]} - ${jumlah[$i]}";
   echo "$date - ${username[$i]} - ${jumlah[$i]}" >> /root/log-limit.txt;
   kill ${pid[$i]};
   pid[$i]="";
   j=`expr $j + 1`;
fi
done
if [ $j -gt 0 ]; then
if [ $OS -eq 1 ]; then
   userdel -f $user
   service ssh restart > /dev/null 2>&1;
fi
if [ $OS -eq 2 ]; then
   userdel -f $user
   service sshd restart > /dev/null 2>&1;
fi
   userdel -f $user
   service dropbear restart > /dev/null 2>&1;
   j=0;
fi
}

# // X P
function xp(){
MYIP=$(wget -qO- ipinfo.io/ip);
clear
##----- Auto Remove Vmess
data=($(cat /etc/xray/config.json | grep '^###' | cut -d ' ' -f 2 | sort | uniq))
now=$(date +"%Y-%m-%d")
for user in "${data[@]}"; do
    exp=$(grep -w "^### $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
    d1=$(date -d "$exp" +%s)
    d2=$(date -d "$now" +%s)
    exp2=$(((d1 - d2) / 86400))
    if [[ "$exp2" -le "0" ]]; then
        sed -i "/^### $user $exp/,/^},{/d" /etc/xray/config.json
        sed -i "/^### $user $exp/,/^},{/d" /etc/vmess/.vmess.db
        rm -rf /etc/vmess/$user
        rm -f /etc/kyt/limit/vmess/ip/$user
	    rm -f /etc/limit/vmess/$user
	    rm -f /var/www/html/vmess-$user.txt
    fi
done

#----- Auto Remove Vless
data=($(cat /etc/xray/config.json | grep '^#&' | cut -d ' ' -f 2 | sort | uniq))
now=$(date +"%Y-%m-%d")
for user in "${data[@]}"; do
    exp=$(grep -w "^#& $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
    d1=$(date -d "$exp" +%s)
    d2=$(date -d "$now" +%s)
    exp2=$(((d1 - d2) / 86400))
    if [[ "$exp2" -le "0" ]]; then
        sed -i "/^#& $user $exp/,/^},{/d" /etc/xray/config.json
        sed -i "/^### $user $exp/,/^},{/d" /etc/vless/.vless.db
        rm -rf /etc/vless/$user
        rm -f /etc/kyt/limit/vless/ip/$user
	    rm -f /etc/limit/vless/$user
	    rm -f /var/www/html/vless-$user.txt
    fi
done

#----- Auto Remove Trojan
data=($(cat /etc/xray/config.json | grep '^#!' | cut -d ' ' -f 2 | sort | uniq))
now=$(date +"%Y-%m-%d")
for user in "${data[@]}"; do
    exp=$(grep -w "^#! $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
    d1=$(date -d "$exp" +%s)
    d2=$(date -d "$now" +%s)
    exp2=$(((d1 - d2) / 86400))
    if [[ "$exp2" -le "0" ]]; then
        sed -i "/^#! $user $exp/,/^},{/d" /etc/xray/config.json
        sed -i "/^### $user $exp/,/^},{/d" /etc/trojan/.trojan.db
        rm -rf /etc/trojan/$user
        rm -f /etc/kyt/trojan/ip/$user
	    rm -f /etc/limit/trojan/$user
	    rm -f /var/www/html/trojan-$user.txt
    fi
done

#----- Auto Remove SS
data=($(cat /etc/xray/config.json | grep '^#!#' | cut -d ' ' -f 2 | sort | uniq))
now=$(date +"%Y-%m-%d")
for user in "${data[@]}"; do
    exp=$(grep -w "^#!# $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
    d1=$(date -d "$exp" +%s)
    d2=$(date -d "$now" +%s)
    exp2=$(((d1 - d2) / 86400))
    if [[ "$exp2" -le "0" ]]; then
        sed -i "/^#!# $user $exp/,/^},{/d" /etc/xray/config.json
        sed -i "/^### $user $exp/,/^},{/d" /etc/shadowsocks/.shadowsocks.db
        rm -rf /etc/shadowsocks/$user
        rm -f /etc/kyt/shadowsocks/ip/$user
	    rm -f /etc/limit/shadowsocks/$user
	    rm -f /var/www/html/sodosokws-$user.txt
    fi
done
systemctl restart xray

##------ Auto Remove SSH
hariini=$(date +%d-%m-%Y)
exp=$(grep -w "^### $user" "/etc/ssh/.ssh.db" | cut -d ' ' -f 3 | sort | uniq)
cat /etc/shadow | cut -d: -f1,8 | sed /:$/d >/tmp/expirelist.txt
totalaccounts=$(cat /tmp/expirelist.txt | wc -l)
for ((i = 1; i <= $totalaccounts; i++)); do
    tuserval=$(head -n $i /tmp/expirelist.txt | tail -n 1)
    username=$(echo $tuserval | cut -f1 -d:)
    userexp=$(echo $tuserval | cut -f2 -d:)
    userexpireinseconds=$(($userexp * 86400))
    tglexp=$(date -d @$userexpireinseconds)
    tgl=$(echo $tglexp | awk -F" " '{print $3}')
    while [ ${#tgl} -lt 2 ]; do
        tgl="0"$tgl
    done
    while [ ${#username} -lt 15 ]; do
        username=$username" "
    done
    bulantahun=$(echo $tglexp | awk -F" " '{print $2,$6}')
    todaystime=$(date +%s)
    if [ $userexpireinseconds -ge $todaystime ]; then
        :
    else
        userdel --force $username
        sed -i "/^### $user $exp /,/^},{/d" /etc/ssh/.ssh.db
        rm -f /etc/ssh/$user
        rm -f /etc/kyt/limit/ssh/ip/${user}
	    rm -f /var/www/html/ssh-$user.txt
    fi
done
systemctl reload ssh
}
# ================================ #
grenbo="\e[92;1m"
NC='\033[0m'
clear
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e "\033[1;93mâ”‚$NC\e[96;1m          MENU MANAGER SSH                $NC"
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e "\033[1;93mâ”‚  ${grenbo}1.${NC} \033[0;36mCreate SSH Account${NC}"
echo -e "\033[1;93mâ”‚  ${grenbo}2.${NC} \033[0;36mTrial SSH Account${NC}"
echo -e "\033[1;93mâ”‚  ${grenbo}3.${NC} \033[0;36mRenew SSH Account${NC}"
echo -e "\033[1;93mâ”‚  ${grenbo}4.${NC} \033[0;36mCheck login SSH Account${NC}"
echo -e "\033[1;93mâ”‚  ${grenbo}5.${NC} \033[0;36mList Member${NC}"
echo -e "\033[1;93mâ”‚  ${grenbo}6.${NC} \033[0;36mDelete Acount SSH${NC}"
echo -e "\033[1;93mâ”‚  ${grenbo}7.${NC} \033[0;36mDelete User Expired${NC}"
echo -e "\033[1;93mâ”‚  ${grenbo}8.${NC} \033[0;36mAuto Killer SSH${NC}"
echo -e "\033[1;93mâ”‚  ${grenbo}9.${NC} \033[0;36mCheck User MultiLogin${NC}"
echo -e "\033[1;93mâ”‚  ${grenbo}10.${NC} \033[0;36mDetail Account${NC}"
echo -e "\033[1;93mâ”‚  ${grenbo}11.${NC} \033[0;36mTendang User SSH${NC}"
echo -e "\033[1;93mâ”‚  ${grenbo}12.${NC} \033[0;36mlock User SSH${NC}"
echo -e "\033[1;93mâ”‚  ${grenbo}13.${NC} \033[0;36mUnlock User SSH${NC}"
echo -e "\033[1;93mâ”‚  ${grenbo}x.${NC} \033[0;36mComeBack${NC}"
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e ""
read -p "Select options >>    " menu
echo -e ""
case $menu in
1)
    addssh
    ;;
2)
    trial
    ;;
3)
    renewssh
    ;;
4)
    cekssh
    ;;
5)
    member
    ;;
6)
    delssh
    ;;
7)
    xp
    ;;
8)
    autokill
    ;;
9)
    ceklim
    ;;
10)
    user-ssh
    ;;
11)
   tendang
   ;;
12)
    user-lock.sh
   ;;
13)
    user-unlock.sh
   ;;
*)
   menu
   ;;
esac
