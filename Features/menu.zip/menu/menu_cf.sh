#!/bin/bash
CHATID=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 3)
KEY=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 2)
TIME="10"
URL="https://api.telegram.org/bot$KEY/sendMessage"
CF_KEY=$(cat /etc/cfkey)
CF_ID=$(cat /etc/cfid)
if [[ -z "$CF_KEY" || -z "$CF_ID" ]]; then
        echo -e "\033[91;1mCF_KEY dan CF_ID belum diatur. Silakan edit sekarang.\033[0m"
        edit_cf
fi
function pointing() {
    clear
    echo -e ""
    echo -e "\033[96;1m============================\033[0m"
    echo -e "\033[93;1m  INPUT DOMAIN N SUB/WILCARD "
    echo -e "\033[96;1m============================\033[0m"
    echo -e "\033[91;1m contoh domain :\033[0m \033[93sshprem.cloud,itachi.cyou,wendivpn.my.id,ssh-prem.xyz\033[0m"
    echo -e "contoh subdomain : wendivpn"
    read -p "DOMAIN :  " domain
    read -p "SUBDOMAIN    :  " sub
    read -p "IP     :  " IP
    echo -e ""
    dns=${sub}.${domain}
    wilcard=*.${dns}
    set -euo pipefail
    # Memeriksa apakah CF_KEY dan CF_ID sudah diatur
    if [[ -z "$CF_KEY" || -z "$CF_ID" ]]; then
        echo -e "\033[91;1mCF_KEY dan CF_ID belum diatur. Silakan edit sekarang.\033[0m"
        edit_cf
    fi
    #domain
    echo "Updating DNS for ${dns}..."
    ZONE=$(curl -sLX GET "https://api.cloudflare.com/client/v4/zones?name=${domain}&status=active" \
         -H "X-Auth-Email: ${CF_ID}" \
         -H "X-Auth-Key: ${CF_KEY}" \
         -H "Content-Type: application/json" | jq -r .result[0].id)

    RECORD=$(curl -sLX GET "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records?name=${dns}" \
         -H "X-Auth-Email: ${CF_ID}" \
         -H "X-Auth-Key: ${CF_KEY}" \
         -H "Content-Type: application/json" | jq -r .result[0].id)

    if [[ "${#RECORD}" -le 10 ]]; then
         RECORD=$(curl -sLX POST "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records" \
         -H "X-Auth-Email: ${CF_ID}" \
         -H "X-Auth-Key: ${CF_KEY}" \
         -H "Content-Type: application/json" \
         --data '{"type":"A","name":"'${dns}'","content":"'${IP}'","ttl":120,"proxied":false}' | jq -r .result.id)
    fi

    RESULT=$(curl -sLX PUT "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records/${RECORD}" \
         -H "X-Auth-Email: ${CF_ID}" \
         -H "X-Auth-Key: ${CF_KEY}" \
         -H "Content-Type: application/json" \
         --data '{"type":"A","name":"'${dns}'","content":"'${IP}'","ttl":120,"proxied":false}')
    #wilcard
    ZONE=$(curl -sLX GET "https://api.cloudflare.com/client/v4/zones?name=${domain}&status=active" \
         -H "X-Auth-Email: ${CF_ID}" \
         -H "X-Auth-Key: ${CF_KEY}" \
         -H "Content-Type: application/json" | jq -r .result[0].id)

    RECORD=$(curl -sLX GET "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records?name=${wilcard}" \
         -H "X-Auth-Email: ${CF_ID}" \
         -H "X-Auth-Key: ${CF_KEY}" \
         -H "Content-Type: application/json" | jq -r .result[0].id)

    if [[ "${#RECORD}" -le 10 ]]; then
         RECORD=$(curl -sLX POST "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records" \
         -H "X-Auth-Email: ${CF_ID}" \
         -H "X-Auth-Key: ${CF_KEY}" \
         -H "Content-Type: application/json" \
         --data '{"type":"A","name":"'${wilcard}'","content":"'${IP}'","ttl":120,"proxied":false}' | jq -r .result.id)
    fi

    RESULT=$(curl -sLX PUT "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records/${RECORD}" \
         -H "X-Auth-Email: ${CF_ID}" \
         -H "X-Auth-Key: ${CF_KEY}" \
         -H "Content-Type: application/json" \
         --data '{"type":"A","name":"'${wilcard}'","content":"'${IP}'","ttl":120,"proxied":false}')

    # Menyalin output ke clipboard
    echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "🍀SUCCESSFULLY POINTING🍀"
    echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "🌹SUBDOMAIN   : $dns" 
    echo -e "🏵️WILCARD    : $wilcard" 
    echo -e "🌺IP SERVER  : $IP" 
    echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    notif_poin
}
function notif_poin() {
TEXT="
<code>◇━━━━━━━━━━━━━━◇</code>
<b>   ⚠️POINTING NOTIF⚠️ </b>
<code>◇━━━━━━━━━━━━━━◇</code>
<b>IP VPS :</b> <code>$IP </code>
<b>DOMAIN :</b> <code>$dns </code>
<b>WILCARD :</b> <code>$wilcard </code>
<code>◇━━━━━━━━━━━━━━◇</code>
<code>BY BOT : @WENDIVPN_BOT</code>
<code>◇━━━━━━━━━━━━━━◇</code>
"
curl -s --max-time $TIME -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL >/dev/null
}
function edit_cf() {
clear
    echo -e "\033[96;1m============================\033[0m"
    echo -e "\033[93;1m  EDIT CF_KEY DAN CF_ID "
    echo -e "\033[96;1m============================\033[0m"
    
    read -p "Masukkan CF_KEY baru: " new_cf_key
    read -p "Masukkan CF_ID baru: " new_cf_id
    
    # Simpan perubahan ke file atau variabel sesuai kebutuhan
    echo "$new_cf_key" > /etc/cfkey
    echo "$new_cf_id" > /etc/cfid
    
    echo -e "CF_KEY dan CF_ID berhasil diperbarui."
read -p "$( echo -e "Press ${orange}[ ${NC}${Font_Green}Enter${Font_White} ${CYAN}]${Font_White} Back to menu . . .") "
menu_cf.sh
}

function list(){
#!/bin/bash
# *Construct the API request*
URL="https://api.cloudflare.com/client/v4/zones"
response=$(curl -s -X GET "$URL" \
  -H "X-Auth-Email: $CF_ID" \
  -H "X-Auth-Key: $CF_KEY" \
  -H "Content-Type: application/json")

# *Check if the API request was successful*
if [[ $(echo "$response" | jq -r '.success') == "true" ]]; then
    echo "Daftar domain dan Zone ID di Cloudflare:"
    echo "$response" | jq -r '.result[] | "\(.name) - Zone ID: \(.id)"'
else
    echo "Gagal mendapatkan data: $(echo "$response" | jq -r '.errors[] | .message')"
fi
read -p "$( echo -e "Press ${orange}[ ${NC}${Font_Green}Enter${Font_White} ${CYAN}]${Font_White} Back to menu . . .") "
menu_cf.sh
}

function delet(){
     clear
echo -e "\033[96;1m============================\033[0m"
echo -e "\033[93;1m  DELET DOMAIN CF "
echo -e "\033[96;1m============================\033[0m"
URL="https://api.cloudflare.com/client/v4/zones"
response=$(curl -s -X GET "$URL" \
  -H "X-Auth-Email: $CF_ID" \
  -H "X-Auth-Key: $CF_KEY" \
  -H "Content-Type: application/json")

# *Check if the API request was successful*
if [[ $(echo "$response" | jq -r '.success') == "true" ]]; then
    echo "Daftar domain dan Zone ID di Cloudflare:"
    echo "$response" | jq -r '.result[] | "\(.name) - Zone ID: \(.id)"'
else
    echo "Gagal mendapatkan data: $(echo "$response" | jq -r '.errors[] | .message')"
read -p "$( echo -e "Press ${orange}[ ${NC}${Font_Green}Enter${Font_White} ${CYAN}]${Font_White} Back to menu . . .") "
menu_cf.sh
fi
read -p "Input Zone ID Domain To Delet: " ZONE_ID

# *URL API untuk menghapus zona*
URL="https://api.cloudflare.com/client/v4/zones/$ZONE_ID"

# *Menghapus domain menggunakan curl*
RESPONSE=$(curl -s -X DELETE "$URL" \
-H "X-Auth-Email: $CF_ID" \
-H "X-Auth-Key: $CF_KEY" \
-H "Content-Type: application/json")

# *Memeriksa respons*
if [[ $(echo "$RESPONSE" | jq -r '.success') == "true" ]]; then
    echo "Domain berhasil dihapus dari Cloudflare."
else
    echo "Gagal menghapus domain. Respons: $RESPONSE"
fi
read -p "$( echo -e "Press ${orange}[ ${NC}${Font_Green}Enter${Font_White} ${CYAN}]${Font_White} Back to menu . . .") "
menu_cf.sh
}
# Menambahkan menu untuk edit CF_KEY dan CF_ID
echo -e "\033[96;1m============================\033[0m"
echo -e "\033[93;1m  MENU POINTING  "
echo -e "\033[96;1m============================\033[0m"
echo -e "1. Pointing Domain"
echo -e "2. Edit CF_KEY dan CF_ID"
echo -e "3. List Domain"
echo -e "4. Delete Domain"
echo -e "5. Exit"
read -p "Pilih opsi (1-4): " option
case $option in
  1)
    pointing_domain
    ;;
  2)
    edit_cf
    ;;
  3)
    list
    ;;
  4)
    delet
    ;;
  5)
    menu
    ;;
  *)
    echo "Opsi tidak valid. Silakan pilih opsi yang benar."
    ;;
esac
