#!/bin/bash
#mkdir -p /etc/vmess/recovery
#mkdir -p /etc/kyt/limit/vmess/ip/recovery
#mkdir -p /etc/limit/vmess/recovery
#mkdir -p /var/www/html/recovery
clear
NUMBER_OF_CLIENTS=$(grep -c -E "^### " "/etc/xray/config.json")
	if [[ ${NUMBER_OF_CLIENTS} == '0' ]]; then
		clear
        echo -e "\033[0;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
        echo -e "           Recovery Vmess          \E[0m"
        echo -e "\033[0;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
		echo ""
		echo "You have no existing clients!"
		echo ""
		echo -e "\033[0;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
        echo ""
        read -n 1 -s -r -p "Press any key to back on menu"
        m-vmess
	fi

	clear
	echo -e "\033[0;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
    echo -e "           Recovery Vmess          \E[0m"
    echo -e "\033[0;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
    echo ""
  	grep -E "^### " "/etc/vmess/config.json" | cut -d ' ' -f 2-3 | column -t | sort | uniq
    echo ""
    red "tap enter to go back"
    echo -e "\033[0;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
	read -rp "Input Username : " user
    if [ -z $user ]; then
    m-vmess
    else
    read -p "Expired (days): " masaaktif
    rm -f /etc/kyt/limit/vmess/ip/recovery/${user}
    rm -f /etc/vmess/recovery/$user
    read -p "Limit User (GB): " Quota
    read -p "Limit User (IP): " iplim
    exp=$(grep -wE "^### $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
    mkdir -p /etc/kyt/limit/vmess/ip
echo ${iplim} >> /etc/kyt/limit/vmess/ip/${user}
if [ ! -e /etc/vmess/ ]; then
  mkdir -p /etc/vmess/
fi

if [ -z ${Quota} ]; then
  Quota="0"
fi

c=$(echo "${Quota}" | sed 's/[^0-9]*//g')
d=$((${c} * 1024 * 1024 * 1024))

if [[ ${c} != "0" ]]; then
  echo "${d}" >/etc/vmess/${user}
fi
    now=$(date +%Y-%m-%d)
    d1=$(date -d "$exp" +%s)
    d2=$(date -d "$now" +%s)
    exp2=$(( (d1 - d2) / 86400 ))
    exp3=$(($exp2 + $masaaktif))
    exp4=`date -d "$exp3 days" +"%Y-%m-%d"`
    sed -i "/### $user/c\### $user $exp4" /etc/xray/config.json
    sed -i "/### $user/c\### $user $exp4" /etc/vmess/.vmess.db
    systemctl restart xray > /dev/null 2>&1
    clear
    echo -e "\033[0;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
    echo " VMESS Account Was Successfully Recovery"
    echo -e "\033[0;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
    echo ""
    echo " Client Name  : $user"
    echo " Expired On   : $exp4"
    echo " User Quota   : $Quota"
    echo " User Limit IP: $iplim"
    echo ""
    echo -e "\033[0;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
    echo ""
    read -n 1 -s -r -p "Press any key to back on menu"
    m-vmess
    fi
    
##----- Auto Move Rcovery Vmess
data=($(cat /etc/xray/config.json | grep '^###' | cut -d ' ' -f 2 | sort | uniq))
now=$(date +"%Y-%m-%d")
for user in "${data[@]}"; do
    exp=$(grep -w "^### $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
    d1=$(date -d "$exp" +%s)
    d2=$(date -d "$now" +%s)
    exp2=$(((d1 - d2) / 86400))
    if [[ "$exp2" -le "0" ]]; then
        mkdir -p /etc/vmess/recovery
        mv -rf /etc/vmess/$user /etc/vmess/recovery
        mkdir -p /etc/kyt/limit/vmess/ip/recovery
        mv -f /etc/kyt/limit/vmess/ip/$user /etc/kyt/limit/vmess/ip/recovery
        mkdir -p /etc/limit/vmess/recovery
	    mv -f /etc/limit/vmess/$user /etc/limit/vmess/recovery
	    mkdir -p /var/www/html/recovery
	    mv -f /var/www/html/vmess-$user.txt /var/www/html/recovery
    fi
done

#----- Auto Move Rcovery Vless
data=($(cat /etc/xray/config.json | grep '^#&' | cut -d ' ' -f 2 | sort | uniq))
now=$(date +"%Y-%m-%d")
for user in "${data[@]}"; do
    exp=$(grep -w "^#& $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
    d1=$(date -d "$exp" +%s)
    d2=$(date -d "$now" +%s)
    exp2=$(((d1 - d2) / 86400))
    if [[ "$exp2" -le "0" ]]; then
        sed -i "/^#& $user $exp/,/^},{/d" /etc/xray/config.json
        sed -i "/^### $user $exp/,/^},{/d" /etc/vless/.vless.db
        rm -rf /etc/vless/$user
        rm -f /etc/kyt/limit/vless/ip/$user
	    rm -f /etc/limit/vless/$user
	    rm -f /var/www/html/vless-$user.txt
    fi
done

#----- Auto Move Rcovery Trojan
data=($(cat /etc/xray/config.json | grep '^#!' | cut -d ' ' -f 2 | sort | uniq))
now=$(date +"%Y-%m-%d")
for user in "${data[@]}"; do
    exp=$(grep -w "^#! $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
    d1=$(date -d "$exp" +%s)
    d2=$(date -d "$now" +%s)
    exp2=$(((d1 - d2) / 86400))
    if [[ "$exp2" -le "0" ]]; then
        sed -i "/^#! $user $exp/,/^},{/d" /etc/xray/config.json
        sed -i "/^### $user $exp/,/^},{/d" /etc/trojan/.trojan.db
        rm -rf /etc/trojan/$user
        rm -f /etc/kyt/trojan/ip/$user
	    rm -f /etc/limit/trojan/$user
	    rm -f /var/www/html/trojan-$user.txt
    fi
done

#----- Auto Move Rcovery SS
data=($(cat /etc/xray/config.json | grep '^#!#' | cut -d ' ' -f 2 | sort | uniq))
now=$(date +"%Y-%m-%d")
for user in "${data[@]}"; do
    exp=$(grep -w "^#!# $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
    d1=$(date -d "$exp" +%s)
    d2=$(date -d "$now" +%s)
    exp2=$(((d1 - d2) / 86400))
    if [[ "$exp2" -le "0" ]]; then
        sed -i "/^#!# $user $exp/,/^},{/d" /etc/xray/config.json
        sed -i "/^### $user $exp/,/^},{/d" /etc/shadowsocks/.shadowsocks.db
        rm -rf /etc/shadowsocks/$user
        rm -f /etc/kyt/shadowsocks/ip/$user
	    rm -f /etc/limit/shadowsocks/$user
	    rm -f /var/www/html/sodosokws-$user.txt
    fi
done

##------ Auto Move Rcovery SSH
hariini=$(date +%d-%m-%Y)
exp=$(grep -w "^### $user" "/etc/ssh/.ssh.db" | cut -d ' ' -f 3 | sort | uniq)
cat /etc/shadow | cut -d: -f1,8 | sed /:$/d >/tmp/expirelist.txt
totalaccounts=$(cat /tmp/expirelist.txt | wc -l)
for ((i = 1; i <= $totalaccounts; i++)); do
    tuserval=$(head -n $i /tmp/expirelist.txt | tail -n 1)
    username=$(echo $tuserval | cut -f1 -d:)
    userexp=$(echo $tuserval | cut -f2 -d:)
    userexpireinseconds=$(($userexp * 86400))
    tglexp=$(date -d @$userexpireinseconds)
    tgl=$(echo $tglexp | awk -F" " '{print $3}')
    while [ ${#tgl} -lt 2 ]; do
        tgl="0"$tgl
    done
    while [ ${#username} -lt 15 ]; do
        username=$username" "
    done
    bulantahun=$(echo $tglexp | awk -F" " '{print $2,$6}')
    todaystime=$(date +%s)
    if [ $userexpireinseconds -ge $todaystime ]; then
        :
    else
        userdel --force $username
        sed -i "/^### $user $exp /,/^},{/d" /etc/ssh/.ssh.db
        rm -f /etc/ssh/$user
        rm -f /etc/kyt/limit/ssh/ip/${user}
	    rm -f /var/www/html/ssh-$user.txt
    fi
done
