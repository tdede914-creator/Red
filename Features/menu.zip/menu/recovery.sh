#!/bin/bash
#mkdir -p /etc/vmess/recovery
#mkdir -p /etc/kyt/limit/vmess/ip/recovery
#mkdir -p /etc/limit/vmess/recovery
#mkdir -p /var/www/html/recovery
clear
NUMBER_OF_CLIENTS=$(grep -c -E "^### " "/etc/vmess/recovery")
	if [[ ${NUMBER_OF_CLIENTS} == '0' ]]; then
		clear
        echo -e "\033[0;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
        echo -e "           Recovery Vmess          \E[0m"
        echo -e "\033[0;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
		echo ""
		echo "You have no existing clients!"
		echo ""
		echo -e "\033[0;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
        echo ""
        read -n 1 -s -r -p "Press any key to back on menu"
        m-vmess
	fi

	clear
	echo -e "\033[0;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
    echo -e "           Recovery Vmess          \E[0m"
    echo -e "\033[0;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
    echo ""
  	grep -E "^### " "/etc/vmess/recovery" | cut -d ' ' -f 2 | column -t | sort | uniq
    echo ""
    red "tap enter to go back"
    echo -e "\033[0;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
	read -rp "Input Username : " user
    if [ -z $user ]; then
    m-vmess
    else
    read -p "Expired (days): " masaaktif
    rm -f /etc/kyt/limit/vmess/ip/recovery/${user}
    rm -f /etc/vmess/recovery/$user
    read -p "Limit User (GB): " Quota
    read -p "Limit User (IP): " iplim
    exp=$(grep -wE "^### $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
    mkdir -p /etc/kyt/limit/vmess/ip
echo ${iplim} >> /etc/kyt/limit/vmess/ip/${user}
if [ ! -e /etc/vmess/ ]; then
  mkdir -p /etc/vmess/
fi

if [ -z ${Quota} ]; then
  Quota="0"
fi

c=$(echo "${Quota}" | sed 's/[^0-9]*//g')
d=$((${c} * 1024 * 1024 * 1024))

if [[ ${c} != "0" ]]; then
  echo "${d}" >/etc/vmess/${user}
fi
    now=$(date +%Y-%m-%d)
    d1=$(date -d "$exp" +%s)
    d2=$(date -d "$now" +%s)
    exp2=$(( (d1 - d2) / 86400 ))
    exp3=$(($exp2 + $masaaktif))
    exp4=`date -d "$exp3 days" +"%Y-%m-%d"`
    sed -i "/### $user/c\### $user $exp4" /etc/xray/config.json
    sed -i "/### $user/c\### $user $exp4" /etc/vmess/.vmess.db
    systemctl restart xray > /dev/null 2>&1
    clear
    echo -e "\033[0;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
    echo " VMESS Account Was Successfully Recovery"
    echo -e "\033[0;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
    echo ""
    echo " Client Name  : $user"
    echo " Expired On   : $exp4"
    echo " User Quota   : $Quota"
    echo " User Limit IP: $iplim"
    echo ""
    echo -e "\033[0;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
    echo ""
    read -n 1 -s -r -p "Press any key to back on menu"
    m-vmess
    fi
    
##----- Auto Move Rcovery Vmess
data=($(cat /etc/xray/config.json | grep '^###' | cut -d ' ' -f 2 | sort | uniq))
now=$(date +"%Y-%m-%d")
for user in "${data[@]}"; do
    exp=$(grep -w "^### $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
    d1=$(date -d "$exp" +%s)
    d2=$(date -d "$now" +%s)
    exp2=$(((d1 - d2) / 86400))
    if [[ "$exp2" -le "0" ]]; then
        mkdir -p /etc/vmess/recovery
        mv -rf /etc/vmess/$user /etc/vmess/recovery
        mkdir -p /etc/kyt/limit/vmess/ip/recovery
        mv -f /etc/kyt/limit/vmess/ip/$user /etc/kyt/limit/vmess/ip/recovery
        mkdir -p /etc/limit/vmess/recovery
	    mv -f /etc/limit/vmess/$user /etc/limit/vmess/recovery
	    mkdir -p /var/www/html/recovery
	    mv -f /var/www/html/vmess-$user.txt /var/www/html/recovery
    fi
done