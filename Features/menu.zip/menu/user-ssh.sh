#!/bin/bash
export HOME=/root
export TERM=xterm
read -p " Imput User :" user
domain=$(cat /etc/xray/domain)
Pass=$(grep -E "###" "/etc/ssh/.ssh.db" | cut -d ' ' -f 3 | sed -n "$user"p)
Quota=$(grep -E "###" "/etc/ssh/.ssh.db" | cut -d ' ' -f 4 | sed -n "$user"p)
iplimit=$(grep -E "###" "/etc/ssh/.ssh.db" | cut -d ' ' -f 5 | sed -n "$user"p)
exp=$(grep -E "###" "/etc/ssh/.ssh.db" | cut -d ' ' -f 6 | sed -n "$user"p)
hariini=`date -d "0 days" +"%Y-%m-%d"`
expayer=`date -d "$exp days" +"%Y-%m-%d"`
IP=$(curl -sS ipv4.icanhazip.com)
CITY=$(cat /etc/xray/city)
ISP=$(cat /etc/xray/isp)


cat > /var/www/html/ssh-$Login.txt <<-END
---------------------------------------------------
Format SSH OVPN Account
---------------------------------------------------
Username : $user
Password  : $Pass
---------------------------------------------------
IP : $IP
Host  : $domain
Port OpenSSH : 443, 80, 22
Port Dropbear : 443, 109
Port Dropbear WS : 443, 109
Port SSH UDP : 1-65535
Port SSH WS  : 80, 8080, 8081-9999
Port SSH SSL WS : 443
Port SSL/TLS  : 400-900
Port OVPN WS SSL : 443
Port OVPN SSL : 443
Port OVPN TCP : 1194
Port OVPN UDP : 2200
BadVPN UDP   : 7100, 7300, 7300
---------------------------------------------------
Aktif Selama     : $masaaktif Hari
Dibuat Pada      : $hariini
Berakhir Pada    : $expayer
---------------------------------------------------
Payload WSS: GET wss://BUG.COM/ HTTP/1.1[crlf]Host: $domain[crlf]Upgrade: websocket[crlf][crlf]
---------------------------------------------------
OVPN Download : https://$domain:81/
---------------------------------------------------

END
function notif(){
CHATID=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 3)
KEY=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 2)
TIME="10"
URL="https://api.telegram.org/bot$KEY/sendMessage"
TEXT=" 
<code>---------------------------------------------------</code>
                           ✨SSH OVPN Account✨
<code>---------------------------------------------------</code>
<code>Username :</code><code>$user</code>
<code>Password  :</code><code>$Pass</code>
<code>Limit Quota :</code><code>$Quota</code>
<code>Limit IP : $</code> iplimit
<code>Host :</code> $domain
<code>---------------------------------------------------</code>
<code>Port 80 :</code><code>$domain:80@$user:$Pass</code>
<code>Port 443 :</code><code>$domain:443@$user:$Pass</code>
<code>Udp Custom :</code><code>$domain:1-65535@$user:$Pass</code>
<code>---------------------------------------------------</code>
<code>Payload WSS  : </code>
```GET wss://BUG.COM/ HTTP/1.1[crlf]Host: $domain[crlf]Upgrade: websocket[crlf][crlf]```
<code>---------------------------------------------------</code>
<code>PAYLOAD TLS: </code>
```GET wss://[host]/ HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
<code>---------------------------------------------------</code>
OVPN Download : https://$domain:81/
<code>---------------------------------------------------</code>
Save Link Account: https://$domain:81/ssh-$user.txt
<code>---------------------------------------------------</code>
Aktif Selama   : $masaaktif Hari
Dibuat Pada    : $hariini
Berakhir Pada  : $expayer
<code>---------------------------------------------------</code>"

curl -s --max-time $TIME -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL >/dev/null
}
notif