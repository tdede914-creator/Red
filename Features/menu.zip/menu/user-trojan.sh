#!/bin/bash
export HOME=/root
export TERM=xterm

PUB=$(cat /etc/slowdns/server.pub)
NS=$(cat /etc/xray/dns)
CITY=$(cat /etc/xray/city)
clear
read -p " Imput User :" user
iplim=$(cat /etc/kyt/limit/trojan/ip/$user)
domain=$(cat /etc/xray/domain)
uuid=$(cat /etc/trojan/.trojan.db | grep $user | awk '{print $4}')
Quota=$(cat /etc/trojan/.trojan.db | grep $user | awk '{print $5}')
exp=$(cat /etc/trojan/.trojan.db | grep $user | awk '{print $3}')
hariini=(date -d "0 days" +"%Y-%m-%d")
trojanlink="trojan://${uuid}@${domain}:443?path=%2Ftrojan-ws&security=tls&host=${domain}&type=ws&sni=${domain}#${user}"
trojanlink1="trojan://${uuid}@${domain}:443?mode=gun&security=tls&type=grpc&serviceName=trojan-grpc&sni=${domain}#${user}"
clear
echo -e ""
echo -e "\033[1;93m====================\033[0m"
echo -e " CREATE TROJAN ACCOUNT          "
echo -e "\033[1;93m====================\033[0m"
echo -e "Remarks          : ${user}"
echo -e "Host/IP          : ${domain}"
echo -e "Host XrayDNS     : ${NS}"
echo -e "Pub Key          : ${PUB}"
echo -e "Quota            : ${Quota}"
echo -e "Limit IP         : ${iplim}"
echo -e "port TLS/WS      : 443"
echo -e "port None TLS/WS : 80,8880,8080"
echo -e "port GRPC        : 443"
echo -e "port OpenClash   : 443"
echo -e "port CDN TLS/WS  : 443"
echo -e "port None TLS/WS : 80,8880,8080"
echo -e "Key              : ${uuid}"
echo -e "Security         : auto"
echo -e "Network          : ws"
echo -e "Dynamic          : http://bugmu.com/path"
echo -e "Path             : /trojan-ws"
echo -e "ServiceName      : trojan-grpc"
echo -e "\033[0;34m====================\033[0m"
echo -e "Link WS          : ${trojanlink}"
echo -e "\033[0;34m====================\033[0m"
echo -e "Link None Ws     : ${trojanlink2}"
echo -e "\033[0;34m====================\033[0m"
echo -e "Link GRPC        : ${trojanlink1}"
echo -e "\033[0;34m====================\033[0m"
echo -e "Link CDN & OpenClash : https://${domain}:81/trojan-$user.txt"
echo -e "\033[0;34m====================\033[0m"
echo -e "Link Qris        :https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${trojanlink}"
echo -e "\033[0;34m====================\033[0m"
echo -e "Berakhir Pada    : $exp"
echo -e "\033[0;34m====================\033[0m"
echo ""
function notif-tr(){
CHATID=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 3)
KEY=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 2)
TIME="10"
URL="https://api.telegram.org/bot$KEY/sendMessage"
TEXT="
<code>---------------------------------------------------</code>
                            ✨XRAY / Trojan ✨
<code>---------------------------------------------------</code>
Remarks     :<code>${user}</code>
Domain      : ${domain}
User Quota  : ${Quota} GB
User Ip     : ${iplimit} Devic
port TLS    : 443
Key         : ${uuid}
ISP          : $ISP
Path TLS    : /trojan 
ServiceName : trojan-grpc
<code>---------------------------------------------------</code>
<code>Link Akun Trojan </code>
<code>---------------------------------------------------</code>
<code>Link WS         : </code>
```${trojanlink}```
<code>---------------------------------------------------</code>
<code>Link GPRC       : </code>
```${trojanlink1}```
<code>---------------------------------------------------</code>
Berakhir Pada    : $expe
<code>---------------------------------------------------</code>
"
curl -s --max-time $TIME -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL >/dev/null
}
notif-tr