#!/bin/bash
export HOME=/root
export TERM=xterm
REPO="https://raw.githubusercontent.com/bowowiwendi/ipvps/main/ip"
EMAIL="bowowiwendi@gmail.com"
USER="bowowiwendi"
function notif-exp(){
TIME="10"
CHATID="5162695441"
KEY="6778508111:AAGmlVVILOA0z4kgLHoA1gD7Hf-maAi9vCQ"
URL="https://api.telegram.org/bot$KEY/sendMessage"
TEXT="<code>──────────────────────────────────</code>
<b>⚠️ YOUR VPS EXPIRED ⚠️</b>
<code>──────────────────────────────────</code>
USER        : $user
VPS IP      : $ip
DATE        : $exp
<code>──────────────────────────────────</code>
"
curl -s --max-time $TIME -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL >/dev/null
}
data=($(curl -sS https://raw.githubusercontent.com/bowowiwendi/ipvps/main/ip | grep '^###' | awk '{print $2}'))  # Mengubah menjadi array
now=$(date +"%Y-%m-%d")
for user in "${data[@]}"; do
    exp=$(curl -sS https://raw.githubusercontent.com/bowowiwendi/ipvps/main/ip | grep -w "^### $user" | awk '{print $3}')
    # Tambahkan kondisi untuk melewati pengguna dengan status "lifetime"
    if [[ "$exp" == "lifetime" ]]; then
        continue
    fi
    ip=$(curl -sS https://raw.githubusercontent.com/bowowiwendi/ipvps/main/ip | grep -w "^### $user" | awk '{print $4}')
    d1=$(date -d "$exp" +%s)
    d2=$(date -d "$now" +%s)
    exp2=$(((d1 - d2) / 86400))
    if [[ "$exp2" -le "2" || "$exp2" -le "1" || "$exp2" -eq "0" ]]; then  # Ubah dari 0 menjadi 1
        notif-exp
    fi
done

# Buat direktori jika belum ada
mkdir -p /root/Backupip

# Download file IP
wget -q -O /root/Backupip/ip "${REPO}" || {
    echo "Gagal mengunduh file IP"
    exit 1
}

cd /root/Backupip || exit

# Konfigurasi git
git config --global user.email "${EMAIL}"
git config --global user.name "${USER}"

# Inisialisasi git dan push
git init
git add ip
git commit -m "update file" 
git branch -M main

# Gunakan HTTPS URL alih-alih SSH
git remote add origin https://github.com/bowowiwendi/Backupip.git
# Tambahkan token GitHub jika diperlukan
# git remote add origin https://${GITHUB_TOKEN}@github.com/bowowiwendi/Backupip.git

git push -f origin main || {
    echo "Gagal melakukan push ke GitHub"
    exit 1
}

# Bersihkan
cd /root
rm -rf /root/Backupip
