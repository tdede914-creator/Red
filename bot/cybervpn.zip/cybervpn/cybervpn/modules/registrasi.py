from cybervpn import *
import subprocess
import datetime as DT
import asyncio

from telethon import Button, events
import sqlite3

# Inisialisasi koneksi database
conn = sqlite3.connect('database.db')
cursor = conn.cursor()

# Fungsi untuk mengirim pesan ke admin
async def send_to_admins(message: str, buttons=None):
    """Kirim pesan ke semua admin"""
    try:
        # Ambil daftar admin dari database
        admins = cursor.execute("SELECT user_id FROM users WHERE level='admin'").fetchall()
        print("Daftar admin:", admins)  # Cetak daftar admin untuk debugging
        
        # Kirim pesan ke setiap admin
        for admin in admins:
            try:
                await bot.send_message(int(admin[0]), message, buttons=buttons)
                print(f"Pesan terkirim ke admin {admin[0]}")
            except Exception as e:
                print(f"Gagal mengirim ke admin {admin[0]}: {e}")
    except Exception as e:
        print(f"Error saat mengambil daftar admin: {e}")

# Fungsi untuk mengecek apakah pengguna sudah terdaftar
def is_user_registered(user_id: str) -> bool:
    """Cek apakah pengguna sudah terdaftar"""
    return cursor.execute("SELECT user_id FROM users WHERE user_id=?", (user_id,)).fetchone() is not None

# Fungsi untuk mendaftarkan pengguna baru
def register_user(user_id: str, saldo: int, level: str):
    """Daftarkan pengguna baru ke database"""
    cursor.execute("INSERT INTO users (user_id, saldo, level) VALUES (?, ?, ?)", (user_id, saldo, level))
    conn.commit()

# Handler untuk registrasi
@bot.on(events.NewMessage(pattern=r"(?:/registrasi)$"))
@bot.on(events.CallbackQuery(data=b'registrasi'))
async def registrasi_handler(event):
    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)

    async def get_username(user_conv):
        await event.respond('**Masukkan usernamemu:**')
        user_msg = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        username = user_msg.raw_text.strip()
        
        # Validasi username
        if not username:
            await event.respond("Username tidak boleh kosong. Silakan coba lagi.", buttons=[
                [Button.inline("🔄 Ulangi", "registrasi")],
                [Button.inline("❌ Batal", "menu")]
            ])
            return None
        return username

    async with bot.conversation(chat) as user_conv:
        user = await get_username(user_conv)
        if not user:
            return  # Berhenti jika username tidak valid

    # Cek apakah pengguna sudah terdaftar
    if is_user_registered(user_id):
        await event.respond("Anda sudah terdaftar. Silakan gunakan akun yang sudah ada.", buttons=[
            [Button.inline("🔙 Kembali", "menu")]
        ])
        return

    # Buat pesan untuk admin
    admin_msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨🔔 Permintaan Registrasi Baru 🔔⟩**
**━━━━━━━━━━━━━━━━**
**» User ID:** `{user_id}`
**» Username:** `{user}`
**» Telegram:** @{sender.username}
**━━━━━━━━━━━━━━━━**
"""
    # Kirim pesan ke admin
    try:
        await send_to_admins(
            admin_msg,
            buttons=[
                [Button.inline("✅ Setuju", f"confirm_reg_{user_id}_{user}"),
                 Button.inline("❌ Tolak", f"reject_reg_{user_id}")]
            ]
        )
    except Exception as e:
        print(f'Error: {e}')
        await event.respond("Terjadi kesalahan saat mengirim permintaan registrasi. Silakan coba lagi.", buttons=[
            [Button.inline("🔄 Ulangi", "registrasi")],
            [Button.inline("❌ Batal", "menu")]
        ])
        return

    # Beri feedback ke pengguna
    await event.respond("""
**━━━━━━━━━━━━━━━━**
**⟨📝 Registrasi Pending 📝⟩**
**━━━━━━━━━━━━━━━━**
**Permintaan registrasi Anda sedang menunggu persetujuan admin.**
**Mohon tunggu notifikasi selanjutnya.**
**━━━━━━━━━━━━━━━━**
""")

# Handler untuk tombol konfirmasi admin
@bot.on(events.CallbackQuery)
async def confirm_registration(event):
    data = event.data.decode('utf-8')
    if data.startswith('confirm_reg_'):
        try:
            _, user_id, username = data.split('_')[1:]
            
            # Cek apakah pengguna sudah terdaftar
            if is_user_registered(user_id):
                await event.edit("Pengguna sudah terdaftar.")
                return

            # Tambahkan ke database
            saldo = 0
            level = "user"
            register_user(user_id, saldo, level)
            
            # Notifikasi ke user
            msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨🕊Registration Success🕊⟩**
**━━━━━━━━━━━━━━━━**
**» Your ID:** `{user_id}`
**» Username:** `{username}`
**» Balance:** `IDR.0`
**» Ketik /menu untuk login**
**━━━━━━━━━━━━━━━━**
"""
            await bot.send_message(int(user_id), msg, buttons=[[Button.inline("Login", "menu")]])
            await event.edit("Registrasi berhasil disetujui")
            
        except Exception as e:
            print(f'Error: {e}')
            await event.edit("Terjadi kesalahan saat memproses registrasi.")
            
    elif data.startswith('reject_reg_'):
        try:
            user_id = data.split('_')[2]
            await bot.send_message(int(user_id), "**Maaf, registrasi Anda ditolak oleh admin**")
            await event.edit("Registrasi ditolak")
        except Exception as e:
            print(f'Error: {e}')
            await event.edit("Terjadi kesalahan saat menolak registrasi.")