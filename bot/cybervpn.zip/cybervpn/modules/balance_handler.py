import sqlite3

async def process_user_balance_ssh(event, user_id):
    try:
        # Koneksi ke database
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        
        # Ambil saldo user
        cursor.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
        current_balance = cursor.fetchone()[0]
        
        # Harga pembuatan akun SSH
        ssh_price = 10000  # contoh harga
        
        # Cek saldo mencukupi
        if current_balance < ssh_price:
            await event.respond("Saldo tidak mencukupi!")
            return False
            
        # Kurangi saldo
        new_balance = current_balance - ssh_price
        cursor.execute("UPDATE users SET balance = ? WHERE user_id = ?", (new_balance, user_id))
        conn.commit()
        
        return True
        
    except Exception as e:
        print(f"Error processing balance: {e}")
        return False
    finally:
        conn.close() 