from cybervpn import *
import subprocess
import json
import re
import base64
import datetime as DT
import requests
import time

@bot.on(events.NewMessage(pattern=r"/broadcast"))
@bot.on(events.CallbackQuery(data=b'broadcast'))
async def broadcast(event):
    if event.is_private:
        return
    if event.sender_id == admin_id:
        await event.respond("Kirimkan pesan/foto/video yang ingin Anda broadcast.")
        response = await event.get_response()
        
        async for user in bot.iter_dialogs():
            if user.is_user:
                try:
                    if response.photo:
                        # Broadcast foto
                        await bot.send_file(user.id, 
                            file=response.photo,
                            caption=response.text if response.text else None)
                    
                    elif response.video:
                        # Broadcast video
                        await bot.send_file(user.id, 
                            file=response.video,
                            caption=response.text if response.text else None)
                    
                    else:
                        # Broadcast teks biasa
                        await bot.send_message(user.id, response.text)
                        
                except Exception as e:
                    print(f"Gagal mengirim ke {user.id}: {e}")
                    continue
                    
        await event.respond("Broadcast selesai!")
    else:
        await event.respond("Anda tidak memiliki izin untuk melakukan broadcast.")
