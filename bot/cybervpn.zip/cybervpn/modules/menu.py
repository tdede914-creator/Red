from cybervpn import *
from telethon import events, Button
import requests

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)
    sh = 'cat /etc/ssh/.ssh.db | grep "###" | wc -l'
    ssh = subprocess.check_output(sh, shell=True).decode("ascii")
    vm = 'cat /etc/xray/config.json | grep "###" | wc -l'
    vms = subprocess.check_output(vm, shell=True).decode("ascii")
    vl = 'cat /etc/vless/.vless.db | grep "###" | wc -l'
    vls = subprocess.check_output(vl, shell=True).decode("ascii")
    tr = 'cat /etc/trojan/.trojan.db | grep "###" | wc -l'
    trj = subprocess.check_output(tr, shell=True).decode("ascii")
    ss = 'cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l'
    ssk = subprocess.check_output(ss, shell=True).decode("ascii")
    sdss = 'cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed \'s/=//g\' | sed \'s/PRETTY_NAME//g\''
    namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
    ipvps = 'curl -s ipv4.icanhazip.com'
    ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
    citsy = 'cat /etc/xray/city'
    city = subprocess.check_output(citsy, shell=True).decode("ascii")

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    [Button.inline("𝚂𝚂𝙷", "ssh")],
                    [Button.inline("𝚅𝚖𝚎𝚜𝚜", "vmess"),
                     Button.inline("𝚅𝚕𝚎𝚜𝚜", "vless")],
                    [Button.inline("𝚃𝚛𝚘𝚓𝚊𝚗", "trojan"),
                     Button.inline("𝚂𝚑𝚊𝚍𝚘𝚠𝚜𝚘𝚌𝚔𝚜", "shadowsocks")],
                    [Button.url("𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖", "https://t.me/WendiVpn"),
                     Button.inline("𝚃𝚘𝚙𝚄𝚙", f"topup")]
                ]

                member_msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
 **🙎‍♂️[̲̅w][̲̅e][̲̅n][̲̅d][̲̅i] [̲̅s][̲̅t][̲̅o][̲̅r][̲̅e]🙎‍♂️**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**HARGA 1 KAUN VPN 2 IP 10K/30 HARI**
**UNTUK LEBIH DARI 30 HARI DAN MELEBIHI 2 IP**
**HUBUNGI ADMIN @WendiVpn**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**🙎‍♂️𝗨𝗦𝗘𝗥 𝗜𝗗 : ** `{user_id}`**
**💰𝗦𝗔𝗟𝗗𝗢𝗠𝗨 : ** `Rp.{saldo_aji}`
**◇━━━━━━━━━━━━━━━━━━━━━━━◇
🤖@WendiVpn
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            elif level == "admin":
                admin_inline = [
                    [Button.inline("𝚂𝚂𝙷", "ssh")],
                    [Button.inline("𝚅𝚖𝚎𝚜𝚜", "vmess"),
                     Button.inline("𝚅𝚕𝚎𝚜𝚜", "vless")],
                    [Button.inline("𝚃𝚛𝚘𝚓𝚊𝚗", "trojan"),
                     Button.inline("𝚂𝚑𝚊𝚍𝚘𝚠𝚜𝚘𝚌𝚔𝚜", "shadowsocks")],
                    [Button.inline("𝙰𝚍𝚍 𝙼𝚎𝚖𝚋𝚎𝚛", "registrasi-member"),
                     Button.inline("𝙷𝚊𝚙𝚞𝚜 𝙼𝚎𝚖𝚋𝚎𝚛", "delete-member")],
                    [Button.inline("𝙳𝚊𝚏𝚝𝚊𝚛 𝙼𝚎𝚖𝚋𝚎𝚛", "show-user")],
                    [Button.inline("𝙰𝚍𝚍 𝚂𝚊𝚕𝚍𝚘 𝚄𝚜𝚎𝚛", "addsaldo")],
                    [Button.inline("𝙲𝚑𝚎𝚌𝚔 𝚅𝚙𝚜 𝙸𝚗𝚏𝚘", "info"),
                     Button.inline("𝙾𝚝𝚑𝚎𝚛 𝚂𝚎𝚝𝚝𝚒𝚗𝚐", "setting")],
                    [Button.url("𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖", "https://t.me/WendiVpn"),
                     Button.inline("𝙼𝚊𝚜𝚞𝚔𝚊𝚗 𝙸𝚙𝚟𝚙𝚜", "regist")],
                    [Button.inline("𝙱𝚛𝚘𝚊𝚍𝚌𝚊𝚜𝚝", "broadcast")],  # Tombol broadcast baru
                ]

                admin_msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
 **🙎‍♂️[̲̅w][̲̅e][̲̅n][̲̅d][̲̅i] [̲̅s][̲̅t][̲̅o][̲̅r][̲̅e]🙎‍♂️**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**⚡️ PANEL MENU ADMIN ⚡️**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
**»🔰OS     :** `{namaos.strip().replace('"','')}`
**»🔰CITY   :** `{city.strip()}`
**»🔰DOMAIN :** `{DOMAIN}`
**»🔰IP VPS :** `{ipsaya.strip()}`
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**»🔰Total Account Created:** 
**»🔰SSH OVPN    :** `{ssh.strip()}` __account__
**»🔰XRAY VMESS  :** `{vms.strip()}` __account__
**»🔰XRAY VLESS  :** `{vls.strip()}` __account__
**»🔰XRAY TROJAN :** `{trj.strip()}` __account__
**»🔰XRAY SHADOWSOCKS:** `{ssk.strip()}` __account__
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**🙎‍♂️𝗨𝗦𝗘𝗥 𝗜𝗗 : ** `{user_id}`**
**💰𝗦𝗔𝗟𝗗𝗢𝗠𝗨 : ** `Rp.{saldo_aji}`
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**🙎‍♂️𝗧𝗢𝗧𝗔𝗟 𝗨𝗦𝗘𝗥 𝗕𝗢𝗧:** `{get_user_count()}`
**◇━━━━━━━━━━━━━━━━━━━━━━━◇
🤖@WendiVpn
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f'**Siilahkan Registrasi Terlebih Dahulu**',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )

