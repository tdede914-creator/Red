from cybervpn import *
import subprocess
import datetime as DT

@bot.on(events.NewMessage(pattern=r"(?:/registrasi)$"))
@bot.on(events.CallbackQuery(data=b'registrasi'))
async def registrasi_handler(event):
    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)

    async def get_username(user_conv):
        await event.edit('**Masukkan usernamemu:**')
        user_msg = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        return user_msg.raw_text

    async with bot.conversation(chat) as user_conv:
        user = await get_username(user_conv)
        
    admin_msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨🔔 Permintaan Registrasi Baru 🔔⟩**
**━━━━━━━━━━━━━━━━**
**» User ID:** `{user_id}`
**» Username:** `{user}`
**» Telegram:** @{sender.username}
**━━━━━━━━━━━━━━━━**
"""
    # Kirim ke admin yang sedang aktif
    try:
        await send_to_admins(
            admin_msg,
            buttons=[
                [Button.inline("✅ Setuju", f"confirm_reg_{user_id}_{user}"),
                 Button.inline("❌ Tolak", f"reject_reg_{user_id}")]
            ]
        )
    except Exception as e:
        print(f'Error: {e}')
        

    await event.respond("""
**━━━━━━━━━━━━━━━━**
**⟨📝 Registrasi Pending 📝⟩**
**━━━━━━━━━━━━━━━━**
**Permintaan registrasi Anda sedang menunggu persetujuan admin.**
**Mohon tunggu notifikasi selanjutnya.**
**━━━━━━━━━━━━━━━━**
""")

# Handler untuk tombol konfirmasi admin
@bot.on(events.CallbackQuery)
async def confirm_registration(event):
    data = event.data.decode('utf-8')
    if data.startswith('confirm_reg_'):
        _, user_id, username = data.split('_')[1:]
        
        # Tambahkan ke database
        saldo = 0
        level = "user"
        register_user(user_id, saldo, level)
        
        # Notifikasi ke user
        msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨🕊Registration Success🕊⟩**
**━━━━━━━━━━━━━━━━**
**» Your ID:** `{user_id}`
**» Username:** `{username}`
**» Balance:** `IDR.0`
**» Ketik /menu untuk login**
**━━━━━━━━━━━━━━━━**
"""
        await bot.send_message(int(user_id), msg, buttons=[[Button.inline("Login", "menu")]])
        await event.edit("Registrasi berhasil disetujui")
        
    elif data.startswith('reject_reg_'):
        user_id = data.split('_')[2]
        await bot.send_message(int(user_id), "**Maaf, registrasi Anda ditolak oleh admin**")
        await event.edit("Registrasi ditolak")

async def send_to_admins(message: str, buttons=None):
    """Kirim pesan ke semua admin"""
    admins = cursor.execute("SELECT user_id FROM users WHERE level='admin'").fetchall()
    for admin in admins:
        try:
            await bot.send_message(int(admin[0]), message, buttons=buttons)
        except Exception as e:
            print(f"Gagal mengirim ke admin {admin[0]}: {e}")

