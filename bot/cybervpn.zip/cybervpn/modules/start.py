from cybervpn import *
import json
from telethon import Button, events

# Baca data VPS dari file JSON
with open("vps_list.json", "r") as f:
    vps_list = json.load(f)
    
selected_vps = None

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))# Fungsi untuk menampilkan menu pemilihan VPS
async def show_vps_menu(event):
    buttons = []
    for vps in vps_list:
        buttons.append([Button.inline(vps["name"], f"select_vps:{vps['ip']}")])
    namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
    ipvps = 'curl -s ipv4.icanhazip.com'
    ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
    citsy = 'cat /etc/xray/city'
    city = subprocess.check_output(citsy, shell=True).decode("ascii")
    username = event.sender.username
    user_id = event.sender_id
    msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
**⚡️ PREMIUM PANEL MENU ⚡️**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
**»🔰 OS     :** `{namaos.strip().replace('"','')}`
**»🔰 CITY   :** `{city.strip()}`
**»🔰 DOMAIN :** `{DOMAIN}`
**»🔰 IP VPS :** `{ipsaya.strip()}`
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
"""
    await event.respond("**Pilih VPS:**", msg, buttons=buttons)
# Handler untuk callback query (ketika tombol dipilih)
@bot.on(events.CallbackQuery(pattern=r"select_vps:(.*)"))
async def handle_vps_selection(event):
    global selected_vps
    selected_ip = event.pattern_match.group(1).decode()  # Ambil IP dari callback data
    selected_vps = selected_ip  # Simpan IP yang dipilih ke variabel global
    await event.respond(f"✅ Anda memilih VPS dengan IP: `{selected_vps}`")

    # Lanjutkan ke menu utama dengan membawa variabel selected_vps
    await start_menu(event, selected_vps)
    




		