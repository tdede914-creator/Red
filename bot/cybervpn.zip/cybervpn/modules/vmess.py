from cybervpn import *
import subprocess
import json
import re
import base64
import datetime as DT
import requests
import time

#detail
@bot.on(events.CallbackQuery(data=b'd-vmess'))
async def l_vmess(event):
	async def l_vmess_(event):
		cmd = 'cat /etc/xray/config.json | grep "^###" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Vmess Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond(" **👤Username:**")
			user = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text.replace(" ", "")
			cmd_check = f'cat /etc/xray/config.json | grep "{user}"'
			if subprocess.call(cmd_check, shell=True) != 0:
				await event.respond("**Username tidak ditemukan. Silakan masukkan username yang benar.**", buttons=[
[Button.inline("🔄 Ulangi","d-vmess")],
[Button.inline("❌ Cancel","vmess")]])
				return
			cmd = f'cat /var/www/html/vmess-{user}.txt'.strip()
			x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd, shell=True).decode("utf-8")
			if z:
				await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Vmess Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
""",buttons=[[Button.inline("🔙Back","vmess")]])
			else:
				await event.respond("**Filed**: User tidak ditemukan", buttons=[[Button.inline("🔙Back","vmess")]])
				
			user_id = str(event.sender_id)
			chat = event.chat_id
			sender = await event.get_sender()
			try:
				level = get_level_from_db(user_id)
				print(f'Retrieved level from database: {level}')

				if 'admin' in level or 'user' in level:
					await l_vmess_(event)
				else:
					await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
			except Exception as e:
				print(f'Error: {e}')

#LOCK VMESS
@bot.on(events.CallbackQuery(data=b'lock-vmess'))
async def lock_vmess(event):
	async def lock_vmess_(event):
		cmd = 'cat /etc/xray/config.json | grep "^###" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Vmess Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond(" **👤Username:**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text.replace(" ", "")
			cmd_check = f'cat /etc/xray/config.json | grep "{user}"'
			if subprocess.call(cmd_check, shell=True) != 0:
				await event.respond("**Username tidak ditemukan. Silakan masukkan username yang benar.**", buttons=[
[Button.inline("🔄 Lock Ulang","lock-vmess")],
[Button.inline("❌ Cancel","vmess")]])
				return
			cmd = f'printf "%s\n" "{user}" | lock-vm'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except subprocess.CalledProcessError:  # Menangani kesalahan jika user tidak ada
			await event.respond(f" **Successfully**", buttons=[[Button.inline("🔙Back","vmess")]])
		else:
			await event.respond(f" **Successfully Lock**", buttons=[[Button.inline("🔙Back","vmess")]])

	user_id = str(event.sender_id)
	chat = event.chat_id
	sender = await event.get_sender()
	try:
		level = get_level_from_db(user_id)
		print(f'Retrieved level from database: {level}')

		if 'admin' in level or 'user' in level:
			await lock_vmess_(event)
		else:
			await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
	except Exception as e:
		print(f'Error: {e}')

#UNLOCK VMESS
@bot.on(events.CallbackQuery(data=b'unlock-vmess'))
async def unlock_vmess(event):
	async def unlock_vmess_(event):
		cmd = 'cat /etc/xray/.lock.db    | grep "^###" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Vmess Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond(" **👤Username:**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text.replace(" ", "")
			cmd_check = f'cat /etc/xray/.lock.db | grep "{user}"'
			if subprocess.call(cmd_check, shell=True) != 0:
				await event.respond("**Username tidak ditemukan. Silakan masukkan username yang benar.**", buttons=[
[Button.inline("🔄 Unlock Ulang","unlock-vmess")],
[Button.inline("❌ Cancel","vmess")]])
				return  # Keluar dari fungsi jika username tidak ditemukan
			cmd = f'printf "%s\n" "{user}" | unlock-vm'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except subprocess.CalledProcessError:  # Menangani kesalahan jika user tidak ada
			await event.respond(f" **Successfully**", buttons=[[Button.inline("🔙Back","vmess")]])
		else:
			await event.respond(f" **Successfully Unlock**", buttons=[[Button.inline("🔙Back","vmess")]])

	user_id = str(event.sender_id)
	chat = event.chat_id
	sender = await event.get_sender()
	try:
		level = get_level_from_db(user_id)
		print(f'Retrieved level from database: {level}')

		if 'admin' in level or 'user' in level:
			await unlock_vmess_(event)
		else:
			await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
	except Exception as e:
		print(f'Error: {e}')

#CRATE VMESS
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
	async def create_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('👤**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text.replace(" ", "")
			cmd_check = f'cat /etc/xray/config.json | grep "{user}"'
			if subprocess.call(cmd_check, shell=True) == 0:
				await event.respond("**Username sudah ada. Silakan masukkan username baru.**", buttons=[
[Button.inline("🔄 Create Ulang","create-vmess")],
[Button.inline("❌ Cancel","vmess")]])
				return  # Keluar dari fungsi jika username sudah ada
		async with bot.conversation(chat) as limit_ip:
			await event.respond("🌐 **Limit IP:**")
			limit_ip = limit_ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limit_ip = (await limit_ip).raw_text
			if not limit_ip.isdigit():
				await event.respond("🌐 **Limit IP harus berupa angka.**", buttons=[
[Button.inline("🔄 Create Ulang","create-vmess")],
[Button.inline("❌ Cancel","vmess")]])
				return  # Keluar dari fungsi jika limit_ip bukan angka
		async with bot.conversation(chat) as pw:
			await event.respond("📦 **Quota:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
			if not pw.isdigit():
				await event.respond("📦 **Quota harus berupa angka.**", buttons=[
[Button.inline("🔄 Create Ulang","create-vmess")],
[Button.inline("❌ Cancel","vmess")]])
				return  # Keluar dari fungsi jika pw bukan angka
		async with bot.conversation(chat) as exp:
			await event.respond("⏳ **Masaaktif:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
			if not exp.isdigit():
				await event.respond("⏳ **Masaaktif harus berupa angka.**", buttons=[
[Button.inline("🔄 Create Ulang","create-vmess")],
[Button.inline("❌ Cancel","vmess")]])
				return  # Keluar dari fungsi jika exp bukan angka
		async with bot.conversation(chat) as bug:
			await event.respond("🐞 **BUG:pilih bug**",buttons=[
[Button.inline("🎥 VIDIO","quiz.int.vidio.com"),
Button.inline("📚 ILMUPEDIA","104.26.7.171")],
[Button.inline("📱 AXIS/XL EDU","104.17.3.81"),
Button.inline("🌍 ISAT EDU","englishtest-stage-7.duolingo.com")],
[Button.inline("🆗 NO BUG","bugkamu.com")]])
			bug = bug.wait_event(events.CallbackQuery)
			bug = (await bug).data.decode("ascii")
		cmd = f'printf "%s\n" "{user}" "{limit_ip}" "{pw}" "{exp}" "{bug}" | addws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User Already Exist**",buttons=[[Button.inline("🔙Back","menu")]])
		else:
			inline=[[Button.inline("🔙Back","vmess")]]
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
			print(b)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			msg = f"""
**◇━━━━━━━━━━━━━━━━━━━◇**
		**⚡️ Xray/Vmess Account ⚡️**
**◇━━━━━━━━━━━━━━━━━━━◇**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{DOMAIN}`
**» Limit IP     :** `{limit_ip}`
**» User Quota   :** `{pw} GB`
**» User ID      :** `{z["id"]}`
**» Security     :** `auto`
**» NetWork      :** `(WS) or (gRPC)`
**» Path TLS     :** `(/multi path)/vmess`
**» Path NLS     :** `(/multi path)/vmess`
**» Path Dynamic :** `http://BUG.COM`
**» ServiceName  :** `vmess-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» Link TLS     :** 
```{b[0].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» Link NTLS    :** 
```{b[1].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» Link GRPC    :** 
```{b[2].strip("'")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» Format OpenClash :** 
https://{DOMAIN}:81/vmess-{user}.txt
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `{later}`
**» 🤖@WendiVpn** 
"""
			await event.respond(msg,buttons=inline)

	user_id = str(event.sender_id)
	chat = event.chat_id
	sender = await event.get_sender()
	try:
		level = get_level_from_db(user_id)
		print(f'Retrieved level from database: {level}')

		if 'admin' in level or 'user' in level:
			await create_vmess_(event)
		else:
			await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
	except Exception as e:
		print(f'Error: {e}')

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
	async def trial_vmess_(event):
		async with bot.conversation(chat) as exp:
			await event.respond(" **Choose Expiry Minutes**",buttons=[
[Button.inline(" 10 Menit ","10"),
Button.inline(" 15 Menit ","15")],
[Button.inline(" 30 Menit ","30"),
Button.inline(" 60 Menit ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'printf "%s\n" "{exp}" | trialws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**",buttons=[[Button.inline("🔙Back","menu")]])
		else:
			inline=[[Button.inline("🔙Back","vmess")]]
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
			print(b)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
		**⚡️ Xray/Vmess Account ⚡️**
**◇━━━━━━━━━━━━━━━━━◇**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{DOMAIN}`
**» User Quota   :** `Unlimited`
**» User ID      :** `{z["id"]}`
**» NetWork      :** `(WS) or (gRPC)`
**» Path TLS     :** `(/multi path)/vmess`
**» Path NLS     :** `(/multi path)/vmess`
**» Path Dynamic :** `http://BUG.COM`
**» ServiceName  :** `vmess-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» Link TLS     :** 
```{b[0].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» Link NTLS    :** 
```{b[1].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» Link GRPC    :** 
```{b[2].strip("'")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» Format OpenClash :** 
https://{DOMAIN}:81/vmess-{z["ps"]}.txt
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `{exp} Minutes`
**» 🤖@WendiVpn** 
"""
			await event.respond(msg,buttons=inline)

	user_id = str(event.sender_id)
	chat = event.chat_id
	sender = await event.get_sender()
	try:
		level = get_level_from_db(user_id)
		print(f'Retrieved level from database: {level}')

		if 'admin' in level or 'user' in level:
			await trial_vmess_(event)
		else:
			await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
	except Exception as e:
		print(f'Error: {e}')

# AUTO VMESS
@bot.on(events.CallbackQuery(data=b'auto-vmess'))
async def auto_vmess(event):
	async def auto_vmess_(event):
		async with bot.conversation(chat) as limit_ip:
			await event.respond("🌐 **Limit IP:**")
			limit_ip = limit_ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limit_ip = (await limit_ip).raw_text
			if not limit_ip.isdigit():
				await event.respond("🌐 **Limit IP harus berupa angka.**", buttons=[
[Button.inline("🔄 Create Ulang","create-vmess")],
[Button.inline("❌ Cancel","vmess")]])
				return  # Keluar dari fungsi jika limit_ip bukan angka
		async with bot.conversation(chat) as pw:
			await event.respond("📦 **Quota:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
			if not pw.isdigit():
				await event.respond("📦 **Quota harus berupa angka.**", buttons=[
[Button.inline("🔄 Create Ulang","create-vmess")],
[Button.inline("❌ Cancel","vmess")]])
				return  # Keluar dari fungsi jika pw bukan angka
		async with bot.conversation(chat) as exp:
			await event.respond("⏳ **Masaaktif:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
			if not exp.isdigit():
				await event.respond("⏳ **Masaaktif harus berupa angka.**", buttons=[
[Button.inline("🔄 Create Ulang","create-vmess")],
[Button.inline("❌ Cancel","vmess")]])
				return  # Keluar dari fungsi 
		async with bot.conversation(chat) as bug:
			await event.respond("🐞 **BUG:pilih bug**",buttons=[
[Button.inline("🎥 VIDIO","quiz.int.vidio.com"),
Button.inline("📚 ILMUPEDIA","104.26.7.171")],
[Button.inline("📱 AXIS/XL EDU","104.17.3.81"),
Button.inline("🌍 ISAT EDU","englishtest-stage-7.duolingo.com")],
[Button.inline("🆗 NO BUG","bugkamu.com")]])
			bug = bug.wait_event(events.CallbackQuery)
			bug = (await bug).data.decode("ascii")
			user = "VmessPrem" + str(random.randint(1000,10000))
			cmd = f'printf "%s\n" "{user}" "{limit_ip}" "{pw}" "{exp}" "{bug}" | addws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**",buttons=[[Button.inline("🔙Back","vmess")]])
		else:
			inline=[[Button.inline("🔙Back","vmess")]]
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
			print(b)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
		**⚡️ Xray/Vmess Account ⚡️**
**◇━━━━━━━━━━━━━━━━━◇**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{DOMAIN}`
**» Limit IP     :** `{limit_ip}`
**» User Quota   :** `Unlimited`
**» User ID      :** `{z["id"]}`
**» NetWork      :** `(WS) or (gRPC)`
**» Path TLS     :** `(/multi path)/vmess`
**» Path NLS     :** `(/multi path)/vmess`
**» Path Dynamic :** `http://BUG.COM`
**» ServiceName  :** `vmess-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» Link TLS     :** 
```{b[0].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» Link NTLS    :** 
```{b[1].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» Link GRPC    :** 
```{b[2].strip("'")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» Format OpenClash :** 
https://{DOMAIN}:81/vmess-{z["ps"]}.txt
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `{later}`
**» 🤖@WendiVpn** 
"""
			await event.respond(msg,buttons=inline)

	user_id = str(event.sender_id)
	chat = event.chat_id
	sender = await event.get_sender()
	try:
		level = get_level_from_db(user_id)
		print(f'Retrieved level from database: {level}')

		if 'admin' in level or 'user' in level:
			await auto_vmess_(event)
		else:
			await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
	except Exception as e:
		print(f'Error: {e}')

@bot.on(events.CallbackQuery(data=b'bot-member-vmess'))
async def bot_member_vmess(event):
	async def bot_member_vmess_(event):
		cmd = 'cat /etc/xray/config.json | grep "^###" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Vmess Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
** Menampilkan Member Vmess**
**» 🤖@WendiVpn**
""",buttons=[[Button.inline("🔙Back","vmess")]])
		
	user_id = str(event.sender_id)
	chat = event.chat_id
	sender = await event.get_sender()
	try:
		level = get_level_from_db(user_id)
		print(f'Retrieved level from database: {level}')

		if 'admin' in level or 'user' in level:
			await bot_member_vmess_(event)
		else:
			await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
	except Exception as e:
		print(f'Error: {e}')

#CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
	async def cek_vmess_(event):
		cmd = 'bot-cek-ws.sh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Vmess Logged🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```					  
{z}
```
**Shows Logged In Users Vmess**
**» 🤖@WendiVpn**
""",buttons=[[Button.inline("🔙Back","vmess")]])
		
	user_id = str(event.sender_id)
	chat = event.chat_id
	sender = await event.get_sender()
	try:
		level = get_level_from_db(user_id)
		print(f'Retrieved level from database: {level}')

		if 'admin' in level or 'user' in level:
			await cek_vmess_(event)
		else:
			await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
	except Exception as e:
		print(f'Error: {e}')
		

@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
	async def delete_vmess_(event):
		cmd = 'cat /etc/xray/config.json | grep "^###" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Vmess Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond(' **👤Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text.replace(" ", "")
			cmd_check = f'cat /etc/xray/config.json | grep "{user}"'
			if subprocess.call(cmd_check, shell=True) != 0:
				await event.respond("**Username tidak ditemukan. Silakan masukkan username yang benar.**", buttons=[
[Button.inline("🔄 Delet Ulang","delete-vmess")],
[Button.inline("❌ Cancel","vmess")]])
				return
			cmd = f'printf "%s\n" "{user}" | delws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except subprocess.CalledProcessError:  # Menangani kesalahan jika user tidak ada
			await event.respond(f" **Successfully**", buttons=[[Button.inline("🔙Back","vmess")]])
		else:
			await event.respond(f" **Successfully Delet**", buttons=[[Button.inline("🔙Back","vmess")]])
	
	user_id = str(event.sender_id)
	chat = event.chat_id
	sender = await event.get_sender()
	try:
		level = get_level_from_db(user_id)
		print(f'Retrieved level from database: {level}')

		if 'admin' in level or 'user' in level:
			await delete_vmess_(event)
		else:
			await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
	except Exception as e:
		print(f'Error: {e}')

@bot.on(events.CallbackQuery(data=b'renew-ws'))
async def renew_ws(event):
	async def renew_ws_(event):
		cmd = 'cat /etc/xray/config.json | grep "^###" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Vmess Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond(' **👤Username Renew:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text.replace(" ", "")
			cmd_check = f'cat /etc/xray/config.json | grep "{user}"'
			if subprocess.call(cmd_check, shell=True) != 0:
				await event.respond("**Username tidak ditemukan. Silakan masukkan username yang benar.**", buttons=[
[Button.inline("🔄 Renew Ulang","renew-ws")],
[Button.inline("❌ Cancel","vmess")]])
				return
		async with bot.conversation(chat) as exp:
			await event.respond(' **Ubah Masaaktif:**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
			if not exp.isdigit():
				await event.respond(" **Masaaktif harus berupa angka.**", buttons=[
[Button.inline("🔄 Renew Ulang","renew-ws")],
[Button.inline("❌ Cancel","vmess")]])
				return  # Keluar dari fungsi jika exp bukan angka
		async with bot.conversation(chat) as quota:
			await event.respond(' **Limit Quota:**')
			quota = quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			quota = (await quota).raw_text
			if not quota.isdigit():
				await event.respond(" **Limit Quota harus berupa angka.**", buttons=[
[Button.inline("🔄 Renew Ulang","renew-ws")],
[Button.inline("❌ Cancel","vmess")]])
				return  # Keluar dari fungsi jika quota bukan angka
		async with bot.conversation(chat) as ip:
			await event.respond(' **Limit Ip:**')
			ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			ip = (await ip).raw_text
			if not ip.isdigit():
				await event.respond(" **Limit Ip harus berupa angka.**", buttons=[
[Button.inline("🔄 Renew Ulang","renew-ws")],
[Button.inline("❌ Cancel","vmess")]])
				return  # Keluar dari fungsi jika ip bukan angka
			cmd = f'printf "%s\n" "{user}" "{exp}" "{quota}" "{ip}" | renewws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Successfully**",buttons=[[Button.inline("🔙Back","vmess")]])
		else:
			await event.respond(f"**Successfully Renew** `{user}`",buttons=[[Button.inline("🔙Back","vmess")]])
	
	user_id = str(event.sender_id)
	chat = event.chat_id
	sender = await event.get_sender()
	try:
		level = get_level_from_db(user_id)
		print(f'Retrieved level from database: {level}')

		if 'admin' in level or 'user' in level:
			await renew_ws_(event)
		else:
			await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
	except Exception as e:
		print(f'Error: {e}')

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline("🤖Auto Name","auto-vmess")],
[Button.inline("☣️Trial","trial-vmess"),
Button.inline("➕Create","create-vmess")],
[Button.inline("♻️Renew","renew-ws"),
Button.inline("👤Member","bot-member-vmess")],
[Button.inline("✅Check","cek-vmess"),
Button.inline("❌Delete","delete-vmess")],
[Button.inline("🔐Lock","lock-vmess"),
Button.inline("🔑Unlock","unlock-vmess")],
[Button.inline("📝Detail","d-vmess")],
[Button.inline("🔙Back","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		vm = f' cat /etc/xray/config.json | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		user_id = sender.id
		username = sender.username
		msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
   **◇⟨🔸VMESS SERVICE🔸⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**»🔰Service:** `VMESS`
**»🔰Jumlah VMESS  :** `{vms.strip()}` __account__
**»🔰Hostname/IP:** `{DOMAIN}`
**»🔰ISP:** `{z["isp"]}`
**»🔰Country:** `{z["country"]}`
**◇━━━━━━━━━━━━━━━━━◇**
**»🆔User ID:** `{user_id}`
**»👤Username:@{username}**
"""
		await event.edit(msg,buttons=inline)


	user_id = str(event.sender_id)
	chat = event.chat_id
	sender = await event.get_sender()
	try:
		level = get_level_from_db(user_id)
		print(f'Retrieved level from database: {level}')

		if 'admin' in level or 'user' in level:
			await vmess_(event)
		else:
			await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
	except Exception as e:
		print(f'Error: {e}')