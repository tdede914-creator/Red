from telethon import *
import datetime as DT
from telethon import *
from .bot import bot
from .add_account import add_account
from .manage_accounts import manage_accounts
from .batch_test_accounts import batch_test_accounts
from .account_detail import account_detail
from .manage_droplets import manage_droplets
from .delete_account import delete_account
from .batch_test_delete_accounts import batch_test_delete_accounts
from .create_droplet import create_droplet
from .list_droplets import list_droplets
from .droplet_detail import droplet_detail
from .droplet_actions import droplet_actions
import requests,time,os,subprocess,re,sqlite3,sys,random,base64,json,math
import logging
#usr/local/bin/kyt
logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

exec(open("kyt/var.txt","r").read())
bot = TelegramClient("ddsdswl","6","eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)
try:
	open("kyt/database.db")
except:
	x = sqlite3.connect("kyt/database.db")
	c = x.cursor()
	c.execute("CREATE TABLE admin (user_id)")
	c.execute("INSERT INTO admin (user_id) VALUES (?)",(ADMIN,))
	x.commit()

def get_db():
	x = sqlite3.connect("kyt/database.db")
	x.row_factory = sqlite3.Row
	return x

def valid(id):
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	if id in a:
		return "true"
	else:
		return "false"
def convert_size(size_bytes):
   if size_bytes == 0:
       return "0B"
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size_bytes, 1024)))
   p = math.pow(1024, i)
   s = round(size_bytes / p, 2)
   return "%s %s" % (s, size_name[i])
