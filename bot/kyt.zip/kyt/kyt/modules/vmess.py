from kyt import *

#CRATE VMESS
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
	async def create_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = await user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
			await event.respond("**Limit IP:**")
			limit_ip = await user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limit_ip = (await limit_ip).raw_text
			await event.respond("**Quota:**")
			pw = await user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline(" 7 Day ","7"),
Button.inline(" 15 Day ","15")],
[Button.inline(" 30 Day ","30"),
Button.inline(" 60 Day ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		try:
			limit_ip = int(limit_ip)
		except ValueError:
			await event.respond("**Error:** Limit IP harus berupa angka.")
			return
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		await asyncio.sleep(3)
		await event.edit("`Processing Crate Premium Account`")
		await asyncio.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(3)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await asyncio.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await asyncio.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" "{limit_ip}" | addws'
		proc = await asyncio.create_subprocess_shell(cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
		stdout, stderr = await proc.communicate()
		if proc.returncode == 0:
			a = stdout.decode("utf-8")
		else:
			await event.respond("**User Already Exist**")
			return
		today = DT.date.today()
		later = today + DT.timedelta(days=int(exp))
		b = [x.group() for x in re.finditer("vmess://(.*)",a)]
		z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
		z = json.loads(z)
		z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
		z1 = json.loads(z1)
		msg = f"""
**━━━━━━━━━━━━━━━━━**
**🇲🇨 Xray/Vmess Account 🇵🇸**
**━━━━━━━━━━━━━━━━━**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{z["add"]}`
**» Limit IP     :** `{limit_ip}`
**» XRAY DNS     :** `{HOST}`
**» User Quota   :** `{pw} GB`
**» Port DNS     :** `443, 53`
**» port TLS     :** `222-1000`
**» Port NTLS    :** `80, 8080, 8081-9999`
**» Port GRPC    :** `443`
**» User ID      :** `{z["id"]}`
**» AlterId      :** `0`
**» Security     :** `auto`
**» NetWork      :** `(WS) or (gRPC)`
**» Path TLS     :** `(/multi path)/vmess`
**» Path NLS     :** `(/multi path)/vmess`
**» Path Dynamic :** `http://BUG.COM`
**» ServiceName  :** `vmess-grpc`
**» Pub Key      :** `{PUB}`
**━━━━━━━━━━━━━━━━━**
**» Link TLS     :** 
``{b[0].strip("'").replace(" ","")}``
**━━━━━━━━━━━━━━━━━**
**» Link NTLS    :** 
``{b[1].strip("'").replace(" ","")}``
**━━━━━━━━━━━━━━━━━**
**» Link GRPC    :** 
``{b[2].strip("'")}``
**━━━━━━━━━━━━━━━━━**
**» Format OpenClash :** https://{DOMAIN}:81/vmess-{user}.txt
**━━━━━━━━━━━━━━━━━**
**» Expired Until:** `{later}`
**» 🤖@WendiVpn** 
"""
		# Fungsi untuk memecah pesan menjadi beberapa bagian
		def split_message(msg, length=4096):
			return [msg[i:i+length] for i in range(0, len(msg), length)]

		# Memecah pesan jika lebih panjang dari 4096 karakter
		msg_parts = split_message(msg)

		# Mengirim setiap bagian pesan secara berurutan
		for part in msg_parts:
			await event.respond(part)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
	async def trial_vmess_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Minutes**",buttons=[
[Button.inline(" 10 Menit ","10"),
Button.inline(" 15 Menit ","15")],
[Button.inline(" 30 Menit ","30"),
Button.inline(" 60 Menit ","60")]])
			exp = await exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		await asyncio.sleep(3)
		await event.edit("`Processing Crate Premium Account`")
		await asyncio.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(3)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await asyncio.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await asyncio.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{exp}" | trialws'
		proc = await asyncio.create_subprocess_shell(cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
		stdout, stderr = await proc.communicate()
		if proc.returncode == 0:
			a = stdout.decode("utf-8")
		else:
			await event.respond("**User Already Exist**")
			return
		today = DT.date.today()
		later = today + DT.timedelta(minutes=int(exp))
		b = [x.group() for x in re.finditer("vmess://(.*)",a)]
		z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
		z = json.loads(z)
		z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
		z1 = json.loads(z1)
		msg = f"""
**━━━━━━━━━━━━━━━━━**
**🇲🇨 Xray/Vmess Account 🇵🇸**
**━━━━━━━━━━━━━━━━━**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{z["add"]}`
**» Limit IP     :** `1`
**» XRAY DNS     :** `{HOST}`
**» User Quota   :** `Unlimited`
**» Port DNS     :** `443, 53`
**» port TLS     :** `222-1000`
**» Port NTLS    :** `80, 8080, 8880, 2082, 2052, 2086 8081-9999`
**» Port GRPC    :** `443`
**» User ID      :** `{z["id"]}`
**» AlterId      :** `0`
**» Security     :** `auto`
**» NetWork      :** `(WS) or (gRPC)`
**» Path TLS     :** `(/multi path)/vmess`
**» Path NLS     :** `(/multi path)/vmess`
**» Path Dynamic :** `http://BUG.COM`
**» ServiceName  :** `vmess-grpc`
**» Pub Key      :** `{PUB}`
**━━━━━━━━━━━━━━━━━**
**» Link TLS     :** 
``{b[0].strip("'").replace(" ","")}``
**━━━━━━━━━━━━━━━━━**
**» Link NTLS    :** 
``{b[1].strip("'").replace(" ","")}``
**━━━━━━━━━━━━━━━━━**
**» Link GRPC    :** 
``{b[2].strip("'")}``
**━━━━━━━━━━━━━━━━━**
**» Format OpenClash :** https://{DOMAIN}:81/vmess-{z["ps"]}.txt
**━━━━━━━━━━━━━━━━━**
**» Expired Until:** `{later}`
**» 🤖@WendiVpn** 
"""
		# Fungsi untuk memecah pesan menjadi beberapa bagian
		def split_message(msg, length=4096):
			return [msg[i:i+length] for i in range(0, len(msg), length)]

		# Memecah pesan jika lebih panjang dari 4096 karakter
		msg_parts = split_message(msg)

		# Mengirim setiap bagian pesan secara berurutan
		for part in msg_parts:
			await event.respond(part)
			
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
	async def cek_vmess_(event):
		cmd = 'bot-cek-ws'.strip()
		proc = await asyncio.create_subprocess_shell(cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
		stdout, stderr = await proc.communicate()
		if proc.returncode == 0:
			z = stdout.decode("utf-8")
		else:
			await event.respond("**Error:** Terjadi kesalahan saat menjalankan perintah.")
			return
		await event.respond(f"""

{z}

**Shows Logged In Users Vmess**
**» 🤖@WendiVpn**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
	async def delete_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = await user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | delws'
		proc = await asyncio.create_subprocess_shell(cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
		stdout, stderr = await proc.communicate()
		if proc.returncode == 0:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
		else:
			await event.respond("**User Not Found**")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline(" TRIAL VMESS ","trial-vmess"),
Button.inline(" CREATE VMESS ","create-vmess")],
[Button.inline(" CHECK VMESS ","cek-vmess"),
Button.inline(" DELETE VMESS ","delete-vmess")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🇲🇨 VMESS MANAGER 🇵🇸**
━━━━━━━━━━━━━━━━━━━━━━━ 
🍉 **» Service:** `VMESS`
🍉 **» Hostname/IP:** `{DOMAIN}`
🍉 **» ISP:** `{z["isp"]}`
🍉 **» Country:** `{z["country"]}`
🤖 **» @WendiVpn**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
	
