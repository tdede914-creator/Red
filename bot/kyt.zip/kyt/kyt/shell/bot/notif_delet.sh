#!/bin/bash
cek=$(grep -c -E "^# BEGIN_Del" /etc/crontab)
if [[ "$cek" = "1" ]]; then
sts="🟢 ON"
else
sts="🔴 OFF"
fi
printf "
◇━━━━━━━━━━━━━━━━━━━━━━━◇
  🔥⇱ AUTO DELET $sts ⇲🔥   
◇━━━━━━━━━━━━━━━━━━━━━━━◇
"