import sys
from .do import do
from .add_account import add_account
from .manage_accounts import manage_accounts
from .batch_test_accounts import batch_test_accounts
from .account_detail import account_detail
from .manage_droplets import manage_droplets
from .delete_account import delete_account
from .batch_test_delete_accounts import batch_test_delete_accounts
from .create_droplet import create_droplet
from .list_droplets import list_droplets
from .droplet_detail import droplet_detail
from .droplet_actions import droplet_actions


def __list_all_modules():
    import glob
    from os.path import basename, dirname, isfile

    mod_paths = glob.glob(dirname(__file__) + "/*.py")
    all_modules = [
        basename(f)[:-3]
        for f in mod_paths
        if isfile(f) and f.endswith(".py") and not f.endswith("__init__.py")
        ]
    return all_modules
ALL_MODULES = sorted(__list_all_modules())
