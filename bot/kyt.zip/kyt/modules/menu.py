from kyt import *
import os
import subprocess  # Import tambahan untuk subprocess

DOMAIN = os.getenv('DOMAIN')  # Misalnya mengambil dari variabel lingkungan

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline(" SSH OVPN MANAGER ", "ssh")],
        [Button.inline(" VMESS MANAGER ", "vmess"), Button.inline(" VLESS MANAGER ", "vless")],
        [Button.inline(" TROJAN MANAGER ", "trojan"), Button.inline(" SHDWSK MANAGER ", "shadowsocks")],
        [Button.inline(" CHECK VPS INFO ", "info"), Button.inline(" OTHER SETTING ", "setting")],
        [Button.inline(" ‹ Back Menu › ", "start")]
    ]
    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        await event.reply("Akses Ditolak")
    elif val == "true":
        try:
            ssh_count = subprocess.check_output("grep '###' /etc/ssh/.ssh.db | wc -l", shell=True).decode("ascii").strip()
            vmess_count = subprocess.check_output("grep '###' /etc/xray/config.json | wc -l", shell=True).decode("ascii").strip()
            vless_count = subprocess.check_output("grep '#&' /etc/vless/.vless.db | wc -l", shell=True).decode("ascii").strip()
            trojan_count = subprocess.check_output("grep '#!' /etc/trojan/.trojan.db | wc -l", shell=True).decode("ascii").strip()
            os_info = subprocess.check_output("grep -w PRETTY_NAME /etc/os-release | cut -d '=' -f2", shell=True).decode("ascii").strip().replace('"', '')
            ip_vps = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()
            city = subprocess.check_output("cat /etc/xray/city", shell=True).decode("ascii").strip()
            cmd = 'info-vps'.strip()
            x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd, shell=True).decode("utf-8")

            msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🇲🇨 ADMIN PANEL MENU 🇵🇸**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» OS     :** `{os_info}`
**» CITY :** `{city}`
**» DOMAIN :** `{DOMAIN}`
**» IP VPS :** `{ip_vps}`
**» Status VPS:** 
{z}
**» Total Account Created:** 
**» 🍉SSH OVPN    :** `{ssh_count}` __account__
**» 🍉XRAY VMESS  :** `{vmess_count}` __account__
**» 🍉XRAY VLESS  :** `{vless_count}` __account__
**» 🍉XRAY TROJAN :** `{trojan_count}` __account__
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
            await event.edit(msg, buttons=inline)
        except Exception as e:
            await event.reply(f"Error: {str(e)}", buttons=inline)
