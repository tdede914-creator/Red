from kyt import *

@bot.on(events.CallbackQuery(data=b'rercvm'))
async def rerc_ws(event):
	async def rerc_ws_(event):
		cmd = 'cat /etc/vmess/.vmess.db | grep "^###" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond('**Username Renew:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond('**Ubah Masaaktif:**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" "{user}" "{exp}" | revm.sh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Not Found**",buttons=[[Button.inline("‹ Menu Vmess ›","vmess")]])
		else:
			await event.respond(f"**Successfully Renew** `{user}`",buttons=[[Button.inline("‹ Menu Vmess ›","vmess")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await rerc_ws_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'rercvl'))
async def rerc_vl(event):
	async def rerc_vl_(event):
		cmd = 'cat /etc/vless/.vless.db | grep "^###" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond('**Username Renew:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond('**Ubah Masaaktif:**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" "{user}" "{exp}" | revl.sh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Not Found**",buttons=[[Button.inline("‹ Menu Vless ›","vless")]])
		else:
			await event.respond(f"**Successfully Renew** `{user}`",buttons=[[Button.inline("‹ Menu Vless ›","vless")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await rerc_vl_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'rerctr'))
async def rerc_tr(event):
	async def rerc_tr_(event):
		cmd = 'cat /etc/trojan/.trojan.db | grep "^###" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond('**Username Renew:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond('**Ubah Masaaktif:**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" "{user}" "{exp}" | retr.sh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Not Found**",buttons=[[Button.inline("‹ Menu Trojan ›","trojan")]])
		else:
			await event.respond(f"**Successfully Renew** `{user}`",buttons=[[Button.inline("‹ Menu Trojan ›","trojan")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await rerc_tr_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'delrcvm'))
async def del_vmess(event):
	async def del_vmess_(event):
		cmd = 'cat /etc/vmess/.vmess.db | grep "^###" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | delrevm.sh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Not Found**",buttons=[[Button.inline("‹ Menu Vmess ›","vmess")]])
		else:
			await event.respond(f"**Successfully Deleted** `{user}`",buttons=[[Button.inline("‹ Menu Vmess ›","vmess")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await del_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'delrcvl'))
async def del_vless(event):
	async def del_vless_(event):
		cmd = 'cat /etc/vless/.vless.db | grep "^###" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | delrevl.sh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			inline=[[Button.inline("‹ Menu Vless ›","vless")]]
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg,buttons=inline)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await del_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'delrctr'))
async def del_trojan(event):
	async def del_trojan_(event):
		cmd = 'cat /etc/trojan/.trojan.db | grep "^###" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | delretr.sh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Not Found**",buttons=[[Button.inline("‹ Menu Trojan ›","trojan")]])
		else:
			await event.respond(f"**Successfully Deleted** `{user}`",buttons=[[Button.inline("‹ Menu Trojan ›","trojan")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await del_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'delall'))
async def rc(event):
    async def rc_(event):
        cmd = 'delallxray.sh'
        await event.edit("Processing...")
        for i in range(0, 101, 4):
            bar = '█' * (i // 4) + '▒' * (25 - i // 4)
            await event.edit(f"`Processing... {i}%\n{bar}`")
            await asyncio.sleep(0.5)  # Adjust sleep time as needed
        subprocess.check_output(cmd, shell=True)
        await event.respond(f"""
**» DEL RECOVERY DONE**
**» 🤖@MakhluktunnelMt**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await rc_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


@bot.on(events.CallbackQuery(data=b'recovery'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline(" RENEW VMESS ","rercvm"),
Button.inline(" DEL VMESS ","delrcvm")],
[Button.inline(" RENEW VLESS ","rercvl"),
Button.inline(" DEL VLESS ","delrcvl")],
[Button.inline(" RENEW TROJAN ","rerctr"),
Button.inline(" DEL TROJAN ","delrctr")],
[Button.inline(" DELETE ALL RECOVERY ","delall")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**☽━━━━━━━━━━━━━━━━━☾** 
**🇲🇨 RECOVERY MANAGER 🇵🇸**
**☽━━━━━━━━━━━━━━━━━☾** 
**»☪Hostname/IP:** `{DOMAIN}`
**»☪ISP:** `{z["isp"]}`
**»☪Country:** `{z["country"]}`
**»🤖@MakhluktunnelMt**
**☽━━━━━━━━━━━━━━━━━☾** 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)

