from kyt import *

@bot.on(events.CallbackQuery(data=b'rercvm'))
async def rerc_ws(event):
	async def rerc_ws_(event):
		cmd = 'cat /etc/xray/.lock.db | grep "^###" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Renew Recovery🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond('**Username Renew:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond('**Ubah Masaaktif:**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		get_uuid = f"cat /etc/xray/.lock.db | grep -w '^### {user}' | cut -d ' ' -f 4"
		try:
			uuid = subprocess.check_output(get_uuid, shell=True).decode().strip()
		except:
			await event.respond(f"**User** `{user}` **Not Found**",buttons=[[Button.inline("‹ Back ›","recovery")]])
			return
		cmd = f'''sed -i '/#vmess$/a\### {user} {exp}\
}},{{"id": "{uuid}","alterId": "0","email": "{user}"' /etc/xray/config.json
    sed -i '/#vmessgrpc$/a\## {user} {exp}\
}},{{"id": "{uuid}","alterId": "0","email": "{user}"' /etc/xray/config.json
sed -i "/^### {user}/d" /etc/xray/.lock.db
systemctl restart xray > /dev/null 2>&1'''
		try:
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"**Successfully Renew** `{user}`",buttons=[[Button.inline("‹ Back ›","recovery")]])
		except:
			await event.respond(f"**Failed to renew user** `{user}`",buttons=[[Button.inline("‹ Back ›","recovery")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await rerc_ws_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'rercvl'))
async def rerc_vl(event):
	async def rerc_vl_(event):
		cmd = 'cat /etc/xray/.lock.db | grep "^#&" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Renew Recovery🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond('**Username Renew:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond('**Ubah Masaaktif:**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		get_uuid = f"cat /etc/xray/.lock.db | grep -w '^#& {user}' | cut -d ' ' -f 4"
		try:
			uuid = subprocess.check_output(get_uuid, shell=True).decode().strip()
		except:
			await event.respond(f"**User** `{user}` **Not Found**",buttons=[[Button.inline("‹ Back ›","recovery")]])
			return
		cmd = f'''sed -i '/#vless$/a\#& {user} {exp}\\
}},{{"id": "{uuid}","email": "{user}"}}' /etc/xray/config.json
sed -i '/#vlessgrpc$/a\#&& {user} {exp}\\
}},{{"id": "{uuid}","email": "{user}"}}' /etc/xray/config.json
sed -i "/^#& {user}/d" /etc/xray/.lock.db
systemctl restart xray > /dev/null 2>&1'''
		try:
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"**Successfully Renew** `{user}`",buttons=[[Button.inline("‹ Back ›","recovery")]])
		except:
			await event.respond(f"**Failed to renew user** `{user}`",buttons=[[Button.inline("‹ Back ›","recovery")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await rerc_vl_(event)
	else:
			await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'rerctr'))
async def rerc_tr(event):
	async def rerc_tr_(event):
		cmd = 'cat /etc/xray/.lock.db | grep "^#!" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Renew Recovery🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond('**Username Renew:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond('**Ubah Masaaktif:**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		get_uuid = f"cat /etc/xray/.lock.db | grep -w '^#! {user}' | cut -d ' ' -f 4"
		try:
			uuid = subprocess.check_output(get_uuid, shell=True).decode().strip()
		except:
			await event.respond(f"**User** `{user}` **Not Found**",buttons=[[Button.inline("‹ Back ›","recovery")]])
			return
		cmd = f'''sed -i '/#trojanws$/a\#! {user} {exp}\\
}},{{"password": "{uuid}","email": "{user}"}}' /etc/xray/config.json
sed -i '/#trojangprc$/a\#!# {user} {exp}\\
}},{{"password": "{uuid}","email": "{user}"}}' /etc/xray/config.json
sed -i "/^#! {user}/d" /etc/xray/.lock.db
systemctl restart xray > /dev/null 2>&1'''
		try:
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"**Successfully Renew** `{user}`",buttons=[[Button.inline("‹ Back ›","recovery")]])
		except:
			await event.respond(f"**Failed to renew user** `{user}`",buttons=[[Button.inline("‹ Back ›","recovery")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await rerc_tr_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'delrcvm'))
async def del_vmess(event):
	async def del_vmess_(event):
		cmd = 'cat /etc/xray/.lock.db | grep "^###" | cut -d " " -f 2-3 | sort | uniq | nl'
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Delet Recovery🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'sed -i "/^### {user}/d" /etc/xray/.lock.db'
		try:
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"**Successfully Deleted** `{user}`",
								buttons=[[Button.inline("‹ Back ›","recovery")]])
		except:
			await event.respond(f"**Failed to delete user** `{user}`",
								buttons=[[Button.inline("‹ Back ›","recovery")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await del_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'delrcvl'))
async def del_vless(event):
	async def del_vless_(event):
		cmd = 'cat /etc/xray/.lock.db | grep "^#&" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Delet Recovery🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'sed -i "/^#& {user}/d" /etc/xray/.lock.db'
		try:
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"**Successfully Deleted** `{user}`",
								buttons=[[Button.inline("‹ Back ›","recovery")]])
		except:
			await event.respond(f"**Failed to delete user** `{user}`",
								buttons=[[Button.inline("‹ Back ›","recovery")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await del_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'delrctr'))
async def del_trojan(event):
	async def del_trojan_(event):
		cmd = 'cat /etc/xray/.lock.db | grep "^#!" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Delet Recovery🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'sed -i "/^#! {user}/d" /etc/xray/.lock.db'
		try:
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"**Successfully Deleted** `{user}`",
								buttons=[[Button.inline("‹ Back ›","recovery")]])
		except:
			await event.respond(f"**Failed to delete user** `{user}`",
								buttons=[[Button.inline("‹ Back ›","recovery")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await del_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'delall'))
async def rc(event):
    async def rc_(event):
        # Perintah untuk menghapus dan membuat ulang database dengan format yang benar
        cmd = '''rm -f /etc/xray/.lock.db && cat > /etc/xray/.lock.db << EOF
# vmess
# vless
# trojan
EOF'''
        await event.edit("Memproses...")
        for i in range(0, 101, 4):
            bar = '█' * (i // 4) + '▒' * (25 - i // 4)
            await event.edit(f"`Memproses... {i}%\n{bar}`")
            await asyncio.sleep(0.5)
        
        # Eksekusi perintah
        subprocess.check_output(cmd, shell=True)
        
        await event.respond(f"""
**» SEMUA DATA RECOVERY BERHASIL DIHAPUS**
**» 🤖@WendiVpn**
""", buttons=[[Button.inline("‹ Back ›","recovery")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await rc_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


@bot.on(events.CallbackQuery(data=b'recovery'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline(" RENEW VMESS ","rercvm"),
Button.inline(" DEL VMESS ","delrcvm")],
[Button.inline(" RENEW VLESS ","rercvl"),
Button.inline(" DEL VLESS ","delrcvl")],
[Button.inline(" RENEW TROJAN ","rerctr"),
Button.inline(" DEL TROJAN ","delrctr")],
[Button.inline(" DELETE ALL RECOVERY ","delall")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
***◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
**⚡️ RECOVERY MANAGER ⚡️**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
**»🔰Hostname/IP:** `{DOMAIN}`
**»🔰ISP:** `{z["isp"]}`
**»🔰Country:** `{z["country"]}`
**◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)

