from kyt import *
import asyncio  # Tambahkan ini

#regist ip
@bot.on(events.CallbackQuery(data=b'regist'))
async def create_ip(event):
	chat = event.chat_id  # Pindahkan ini ke atas
	sender = await event.get_sender()
	async def create_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**REGIST IP VPS:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as limit_ip:
			await event.respond("**USER VPS:**")
			limit_ip = limit_ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limit_ip = (await limit_ip).raw_text
		async with bot.conversation(chat) as bug:
			await event.respond("**Expired VPS**",buttons=[
[Button.inline(" 30 ","30"),
Button.inline(" 60 ","60")],
[Button.inline(" 90 ","90"),
Button.inline(" lifetime ","lifetime")]])
			bug = bug.wait_event(events.CallbackQuery)
			bug = (await bug).data.decode("ascii")
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		await asyncio.sleep(3)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing Crate Premium Account`")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(3)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await asyncio.sleep(0)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Wait.. Proses Regist VPS`")
		cmd = f'printf "%s\n" "{user}" "{limit_ip}" "{bug}" | add-vps'
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**SUCSESS REGIST VPS**
**»🤖@WendiVpn** 
""",buttons=[[Button.inline("‹ Menu Utama ›","menu")]])
	a = valid(str(sender.id))
	if a == "true":
		await create_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
