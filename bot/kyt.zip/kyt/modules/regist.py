from kyt import *
import asyncio  # Tambahkan ini
import subprocess

@bot.on(events.CallbackQuery(data=b'add-vps'))
async def create_ip(event):
	chat = event.chat_id  # Pindahkan ini ke atas
	sender = await event.get_sender()
	async def create_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**⛩️REGIST IP VPS⛩️:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as ip:
			await event.respond("**🔶USER NAME VPS🔶:**")
			ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			ip = (await ip).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**📅Expired VPS📅:**",buttons=[
[Button.inline("📅 30 DAY 📅","30"),
Button.inline("📅 60 DAY 📅","60")],
[Button.inline("📅 90 DAY 📅","90"),
Button.inline("📅LIFETIME📅 ","lifetime")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		await asyncio.sleep(3)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing Regist Script`")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(3)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await asyncio.sleep(0)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Wait.. Proses Regist VPS`")
		cmd = f'printf "%s\n" "{user}" "{ip}" "{exp}" | add-vps.sh'
		try:
			output = subprocess.check_output(cmd, shell=True).decode("utf-8")  # Simpan output
		except subprocess.CalledProcessError as e:
			await event.respond(f"**❌Regist IP Gagal❌** {str(e)}",buttons=[Button.inline("‹ Back ›","menu")])  # Menggunakan str(e) untuk mendapatkan pesan kesalahan
			return  # Tambahkan return untuk menghentikan eksekusi jika ada error
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
	**📆SUCSESS REGIST VPS📆**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**🆕UPDATE & UPGRADE UBUNTU 20🆕**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
`apt update && apt upgrade -y && update-grub && sleep 2 && reboot`
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**🆕INSTALL AUTO SCRIPT NEXT🆕**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
```sysctl -w net.ipv6.conf.all.disable_ipv6=1 && sysctl -w net.ipv6.conf.default.disable_ipv6=1 && apt install -y && apt update -y && apt upgrade -y && apt install lolcat -y && gem install lolcat && wget -q https://raw.githubusercontent.com/bowowiwendi/WendyVpn/ABSTRAK/setup-main.sh && chmod +x setup-main.sh && ./setup-main.sh```
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**» 🤖@WendiVpn** 
""",buttons=[Button.inline("‹ Back ›","menu")])
	a = valid(str(sender.id))
	if a == "true":
		await create_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'del-ip'))
async def delete_ip(event):
	async def delete_ip_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**🔶IP VPS TO DELET:**🔶')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		await asyncio.sleep(3)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... Delet User`")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(3)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await asyncio.sleep(0)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Wait.. Proses Delet IP VPS`")
		cmd = f'printf "%s\n" "{user}" | del-ip.sh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**❎IP** `{user}` **Not Found**❎",buttons=[Button.inline("‹ Back ›","menu")])
		else:
			await event.respond(f"**✅Successfully Deleted✅** `{user}`",buttons=[Button.inline("‹ Back ›","menu")])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ip_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b're-ip'))
async def delete_ip(event):
	async def delete_ip_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**🔶IP VPS TO RENEW:**🔶')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as bug:
			await event.respond("**⏳Expired VPS:**⏳",buttons=[
[Button.inline(" ⏳30⏳ ","30"),
Button.inline(" ⏳60⏳ ","60")],
[Button.inline(" ⏳90⏳ ","90"),
Button.inline(" ⏳LIFETIME⏳ ","lifetime")]])
			bug = bug.wait_event(events.CallbackQuery)
			bug = (await bug).data.decode("ascii")
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		await asyncio.sleep(3)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing Renew Script`")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(3)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await asyncio.sleep(0)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Wait.. Proses Renew VPS`")
		cmd = f'printf "%s\n" "{user}" "{bug}" |renew-ip.sh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**IP** `{user}` **Not Found**",buttons=[Button.inline("‹ Back ›","menu")])
		else:
			await event.respond(f"**Successfully Renew** `{user}`",buttons=[Button.inline("‹ Back ›","menu")])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ip_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'ls-ip'))
async def ls_ip(event):
	async def ls_ip_(event):
		chat = event.chat_id  # Pindahkan ini ke atas
		sender = await event.get_sender()
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		await asyncio.sleep(3)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing List Script`")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(3)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await asyncio.sleep(0)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Wait.. Proses List VPS`")  # Pindahkan ini ke atas
		cmd_fetch = 'rm -rf /root/ipvps; mkdir -p /root/ipvps; touch /root/ipvps/ip; wget -q -O /root/ipvps/ip "https://raw.githubusercontent.com/bowowiwendi/ipvps/main/ip"'  # Tambahkan -p untuk mkdir
		try:
			subprocess.run(cmd_fetch, shell=True, check=True)  # Tambahkan check=True
		except subprocess.CalledProcessError as e:
			await event.respond(f"**❌ Gagal mengambil IP: {str(e)} ❌**", buttons=[Button.inline("‹ 🔙 ›", "menu")])
			return

		# Tampilkan daftar IP
		cmd_list = 'cat /root/ipvps/ip | grep "^###" | cut -d " " -f 2-3 | sort | uniq | nl'
		z = subprocess.check_output(cmd_list, shell=True).decode("utf-8")
		await event.respond(f"""
```
{z}
```
""", buttons=[Button.inline("‹ 🔙 ›", "menu")])
	# chat dan sender sudah didefinisikan di atas, tidak perlu didefinisikan lagi
	a = valid(str(sender.id))
	if a == "true":
		await ls_ip_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)


@bot.on(events.CallbackQuery(data=b'regist'))
async def settings(event):
    async def settings_(event):
        inline = [
[Button.inline(" ⬆️REGIST IP⬆️ ","add-vps"),
Button.inline(" 🗑️DELET IP🗑️ ","del-ip")],
[Button.inline(" 📜LIST IP VPS📜 ","ls-ip"),
Button.inline(" 📝RENEW IP📝 ","re-ip")],
[Button.inline("‹ Back ›","menu")]]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
**⚜️ PREMIUM AUTO SCRIPT ⚜️**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
**»🔰Hostname/IP:** `{DOMAIN}`
**»🔰ISP:** `{z["isp"]}`
**»🔰Country:** `{z["country"]}`
**◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
""" 
        await event.edit(msg,buttons=inline)
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await settings_(event)
    else:
        await event.answer("Access Denied",alert=True)

