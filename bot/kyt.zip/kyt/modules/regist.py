from kyt import *
import asyncio  # Tambahkan ini

#regist ip
@bot.on(events.CallbackQuery(data=b'add-vps'))
async def create_ip(event):
	chat = event.chat_id  # Pindahkan ini ke atas
	sender = await event.get_sender()
	async def create_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**REGIST IP VPS:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as limit_ip:
			await event.respond("**USER VPS:**")
			limit_ip = limit_ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limit_ip = (await limit_ip).raw_text
		async with bot.conversation(chat) as bug:
			await event.respond("**Expired VPS:**",buttons=[
[Button.inline(" 30 ","30"),
Button.inline(" 60 ","60")],
[Button.inline(" 90 ","90"),
Button.inline(" LIFETIME ","LIFETIME")]])
			bug = bug.wait_event(events.CallbackQuery)
			bug = (await bug).data.decode("ascii")
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		await asyncio.sleep(3)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing Crate Premium Account`")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(3)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await asyncio.sleep(0)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Wait.. Proses Regist VPS`")
		cmd = f'printf "%s\n" "{user}" "{limit_ip}" "{bug}" | add-vps.sh'
		try:
			output = subprocess.check_output(cmd, shell=True).decode("utf-8")  # Simpan output
		except subprocess.CalledProcessError as e:
			await event.respond(f"**Error:** {e.output.decode('utf-8')}")
			return  # Tambahkan return untuk menghentikan eksekusi jika ada error
		await event.respond(f"""
**SUCSESS REGIST VPS**
**»🤖@WendiVpn** 
""",buttons=[[Button.inline("‹ Menu Utama ›","menu")]])
	a = valid(str(sender.id))
	if a == "true":
		await create_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'del-ip'))
async def delete_ip(event):
	async def delete_ip_(event):
		cmd = 'git clone https://github.com/bowowiwendi/ipvps.git; cat /root/ipvps/ip | grep "^###" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond('**IP VPS:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		await asyncio.sleep(3)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing Crate Premium Account`")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(3)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await asyncio.sleep(0)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Wait.. Proses Regist VPS`")
		cmd = f'printf "%s\n" "{user}" | del-ip.sh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**IP** `{user}` **Not Found**",buttons=[[Button.inline("‹ Menu ›","menu")]])
		else:
			await event.respond(f"**Successfully Deleted** `{user}`",buttons=[[Button.inline("‹ Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ip_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b're-ip'))
async def delete_ip(event):
	async def delete_ip_(event):
		cmd = 'git clone https://github.com/bowowiwendi/ipvps.git; cat /root/ipvps/ip | grep "^###" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond('**IP VPS:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as bug:
			await event.respond("**Expired VPS:**",buttons=[
[Button.inline(" 30 ","30"),
Button.inline(" 60 ","60")],
[Button.inline(" 90 ","90"),
Button.inline(" LIFETIME ","LIFETIME")]])
			bug = bug.wait_event(events.CallbackQuery)
			bug = (await bug).data.decode("ascii")
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		await asyncio.sleep(3)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing Crate Premium Account`")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(3)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await asyncio.sleep(0)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Wait.. Proses Regist VPS`")
		cmd = f'printf "%s\n" "{user} {bug}" |renew-ip.sh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**IP** `{user}` **Not Found**",buttons=[[Button.inline("‹ Menu ›","menu")]])
		else:
			await event.respond(f"**Successfully Renew** `{user}`",buttons=[[Button.inline("‹ Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ip_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'ls-ip'))
async def ls_ip(event):
	async def ls_ip_(event):
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		await asyncio.sleep(3)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing Crate Premium Account`")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(3)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(2)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		await asyncio.sleep(1)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		await asyncio.sleep(0)  # Ganti time.sleep dengan asyncio.sleep
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await asyncio.sleep(1) 
		cmd = 'git clone https://github.com/bowowiwendi/ipvps.git; cat /root/ipvps/ip | grep "^###" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```
{z}
```
""",buttons=[[Button.inline("‹ Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ls_ip_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)


@bot.on(events.CallbackQuery(data=b'regist'))
async def settings(event):
    async def settings_(event):
        inline = [
[Button.inline(" ✅REGIST IP✅ ","add-vps"),
Button.inline(" ❎DELET IP❎ ","del-ip")],
[Button.inline(" 📜LIST IP VPS📜 ","ls-ip"),
Button.inline(" 📝RENEW IP📝 ","re-ip")]]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
**⚜️ PREMIUM PANEL MENU ⚜️**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
**»🔰Hostname/IP:** `{DOMAIN}`
**»🔰ISP:** `{z["isp"]}`
**»🔰Country:** `{z["country"]}`
**»🤖@WendiVpn**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
"""
        await event.edit(msg,buttons=inline)
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await settings_(event)
    else:
        await event.answer("Access Denied",alert=True)

