from kyt import *
import asyncio

@bot.on(events.CallbackQuery(data=b'regis'))
async def create_ip(event):
	async def create_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as limit_ip:
			await event.respond("**IP VPS:**")
			limit_ip = limit_ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limit_ip = (await limit_ip).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**EXPIRED:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(3)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(3)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{user}" "{limit_ip}" "{pw}" | ipvps'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User Already Exist**",buttons=[[Button.inline("‹ Menu Utama ›","menu")]])
		else:
			inline=[[Button.inline("‹ Main Menu ›","menu")]]
			today = DT.date.today()
			msg = f"""
**━━━━━━━━━━━━━━━━━**
**🇲🇨  REGIS IP 🇵🇸**
**━━━━━━━━━━━━━━━━━**
**» User         :** `{user}`
**» IP VPS       :** `{limit_ip}`
**» EXPIRED      :** `{pw}`
**» Tanggal      :** `{today}`
**» 🤖@WendiVpn** 
"""
			await event.respond(msg,buttons=inline)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'reboot'))
async def rebooot(event):
    async def rebooot_(event):
        cmd = 'reboot | bot-vps-info'
        await event.edit("Processing...")
        for i in range(0, 101, 4):
            bar = '█' * (i // 4) + '▒' * (25 - i // 4)
            await event.edit(f"`Processing... {i}%\n{bar}`")
            await asyncio.sleep(0.5)  # Adjust sleep time as needed
        try:
            result = await asyncio.create_subprocess_shell(cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
            output, _ = await result.communicate()
            output = output.decode('utf-8')
        except Exception as e:
            output = str(e)
        await event.respond(f"""{output}```
**» REBOOT SERVER**
**» 🤖@WendiVpn**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await rebooot_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'resx'))
async def resx(event):
    async def resx_(event):
        cmd = 'systemctl restart xray | systemctl restart nginx | systemctl restart haproxy | systemctl restart server | systemctl restart client'
        await event.edit("Processing...")
        for i in range(0, 101, 4):
            bar = '█' * (i // 4) + '▒' * (25 - i // 4)
            await event.edit(f"`Processing... {i}%\n{bar}`")
            await asyncio.sleep(0.5)  # Adjust sleep time as needed
        await event.respond(f"""
**» Restarting Service Done**
**» 🤖@WendiVpn**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await resx_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'speedtest'))
async def speedtest(event):
    async def speedtest_(event):
        cmd = 'speedtest-cli --share'
        await event.edit("Processing...")
        for i in range(0, 101, 4):
            bar = '█' * (i // 4) + '▒' * (25 - i // 4)
            await event.edit(f"`Processing... {i}%\n{bar}`")
            await asyncio.sleep(0.5)  # Adjust sleep time as needed
        try:
            result = await asyncio.create_subprocess_shell(cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
            output, _ = await result.communicate()
            output = output.decode('utf-8')
        except Exception as e:
            output = str(e)
        await event.respond(f"""
**
{output}
**
**» 🤖@WendiVpn**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await speedtest_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'backup'))
async def backup(event):
    async def backup_(event):
        cmd = 'bot-backup'
        await event.edit("Processing...")
        for i in range(0, 101, 4):
            bar = '█' * (i // 4) + '▒' * (25 - i // 4)
            await event.edit(f"`Processing... {i}%\n{bar}`")
            await asyncio.sleep(0.5)  # Adjust sleep time as needed
        subprocess.check_output(cmd, shell=True)
        await event.respond(f"""
**» BACKUP DONE**
**» 🤖@WendiVpn**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await backup_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'restore'))
async def restore(event):
    async def restore_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Input Link Backup:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        cmd = f'printf "%s\n" "{user}" | bot-restore'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond(f"**Link Not Found**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        else:
            await event.respond(f"**Successfully**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await restore_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'fixdomain'))
async def fixcert(event):
    async def fixcert_(event):
        cmd = 'fixcert'
        await event.edit("Processing...")
        for i in range(0, 101, 4):
            bar = '█' * (i // 4) + '▒' * (25 - i // 4)
            await event.edit(f"`Processing... {i}%\n{bar}`")
            await asyncio.sleep(0.5)  # Adjust sleep time as needed
        subprocess.check_output(cmd, shell=True)
        await event.respond(f"""
**» FIX DOMAIN DONE**
**» 🤖@WendiVpn**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await fixcert_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'host'))
async def addhost(event):
    async def addhost_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Domain:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        await event.edit("Processing...")
        for i in range(0, 101, 4):
            bar = '█' * (i // 4) + '▒' * (25 - i // 4)
            await event.edit(f"`Processing... {i}%\n{bar}`")
            await asyncio.sleep(0.5)  # Adjust sleep time as needed
        cmd = f'printf "%s\n" "{user}" | addhost'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond(f"**Domain Gagal**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        else:
            await event.respond(f"**Successfully**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await addhost_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'auto_delet'))
async def auto_delet(event):
    async def auto_delet_(event):
        cmd = 'notif_delet'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
{z}""")
        async with bot.conversation(chat) as exp:
            await event.respond("**Pilih**",buttons=[
                [Button.inline(" ON ","1"),
                 Button.inline(" OFF ","2")],
                [Button.inline("‹ Main Setting ›", "setting")]])
            exp = exp.wait_event(events.CallbackQuery)
            exp = (await exp).data.decode("ascii")
        cmd = f'printf "%s\n" "{exp}" | auto-delet.sh'
        subprocess.check_output(cmd, shell=True)
        await event.respond(f"""
**» SUKSES SETTING AUTO DEL**
**» 🤖@WendiVpn**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await auto_delet_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'auto_backup'))
async def auto_backup(event):
    async def auto_backup_(event):
        cmd = 'notif_backup'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
{z}""")
        async with bot.conversation(chat) as exp:
            await event.respond("**Pilih**",buttons=[
                [Button.inline(" ON ","6"),
                Button.inline(" OFF ","8")],
                [Button.inline("‹ Main Setting ›", "setting")]])
            exp = exp.wait_event(events.CallbackQuery)
            exp = (await exp).data.decode("ascii")
        cmd = f'printf "%s\n" "{exp}" | auto-backup.sh'
        subprocess.check_output(cmd, shell=True)
        await event.respond(f"""
**» SUKSES SETTING AUTO BACKUP**
**» 🤖@WendiVpn**
""", buttons=[[Button.inline("‹ Main Setting ›", "setting")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await auto_backup_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'limit'))
async def auto_limit(event):
    async def auto_limit_(event):
        cmd = 'notif_limit'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
{z}""")
        async with bot.conversation(chat) as exp:
            await event.respond("**Pilih**",buttons=[
                [Button.inline(" ON ","1"),
                Button.inline(" OFF ","2")]])
            exp = exp.wait_event(events.CallbackQuery)
            exp = (await exp).data.decode("ascii")
        cmd = f'printf "%s\n" "{exp}" | onoff'
        subprocess.check_output(cmd, shell=True)
        await event.respond(f"""
**» SUKSES SETTING LIMIT IP**
**» 🤖@WendiVpn**
""",buttons=[[Button.inline("‹ Main Setting ›", "setting")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await auto_limit_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'addbackup'))
async def add_backup(event):
    async def add_backup_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**TOKEN API:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        async with bot.conversation(chat) as exp:
            await event.respond('**USER ID:**')
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text
        cmd = f'printf "%s\n" "{user}" "{exp}" | add-bot-notif'
        await event.edit("Processing...")
        for i in range(0, 101, 4):
            bar = '█' * (i // 4) + '▒' * (25 - i // 4)
            await event.edit(f"`Processing... {i}%\n{bar}`")
            await asyncio.sleep(0.5)  # Adjust sleep time as needed
        subprocess.check_output(cmd, shell=True)
        await event.respond(f"""
**» ADD BOT BACKUP N NOTIF SUKSES**
**» 🤖@WendiVpn**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await add_backup_(event)
    else:
        await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'updatebot'))
async def update_bot(event):
    async def update_bot_(event):
        cmd = f'printf "%s\n" "23" | menu'
        await event.edit("Processing...")
        for i in range(0, 101, 4):
            bar = '█' * (i // 4) + '▒' * (25 - i // 4)
            await event.edit(f"`Processing... {i}%\n{bar}`")
            await asyncio.sleep(0.5)  # Adjust sleep time as needed
        subprocess.check_output(cmd, shell=True)
        await event.respond(f"""
**» UPDATE SCRIPT SUKSES**
**» 🤖@WendiVpn**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await update_bot_(event)
    else:
        await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'delbackup'))
async def del_backup(event):
    async def del_backup_(event):
        cmd = f'del-bot-notif'
        await event.edit("Processing...")
        for i in range(0, 101, 4):
            bar = '█' * (i // 4) + '▒' * (25 - i // 4)
            await event.edit(f"`Processing... {i}%\n{bar}`")
            await asyncio.sleep(0.5)  # Adjust sleep time as needed
        subprocess.check_output(cmd, shell=True)
        await event.respond(f"""
**» DELET BOT BACKUP N NOTIF DONE**
**» 🤖@WendiVpn**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await del_backup_(event)
    else:
        await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'backer'))
async def backers(event):
    async def backers_(event):
        inline = [
[Button.inline(" Add Bot Backup","addbackup"),
Button.inline(" Del Bot Backup","delbackup")],
[Button.inline(" BACKUP","backup"),
Button.inline(" RESTORE","restore")],
[Button.inline("‹ Main Menu ›","menu")]]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🇲🇨 PREMIUM PANEL MENU 🇵🇸**
━━━━━━━━━━━━━━━━━━━━━━━ 
🍉 **» Hostname/IP:** `{DOMAIN}`
🍉 **» ISP:** `{z["isp"]}`
🍉 **» Country:** `{z["country"]}`
🤖 **» @WendiVpn**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        await event.edit(msg,buttons=inline)
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await backers_(event)
    else:
        await event.answer("Access Denied",alert=True)


@bot.on(events.CallbackQuery(data=b'setting'))
async def settings(event):
    async def settings_(event):
        inline = [
[Button.inline(" LIMIT IP","limit"),
Button.inline(" REGIS IP ","regis")],
[Button.inline(" FIX DOMAIN","fixdomain"),
Button.inline(" RUBAH DOMAIN","host")],
[Button.inline(" AUTO DELET","auto_delet"),
Button.inline(" AUTO BACKUP","auto_backup")],
[Button.inline(" SPEEDTEST","speedtest"),
Button.inline(" BACKUP & RESTORE","backer")],
[Button.inline(" REBOOT SERVER","reboot"),
Button.inline(" RESTART SERVICE","resx")],
[Button.inline("‹ Main Menu ›","menu")]]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🇲🇨 PREMIUM PANEL MENU 🇵🇸**
━━━━━━━━━━━━━━━━━━━━━━━ 
🍉 **» Hostname/IP:** `{DOMAIN}`
🍉 **» ISP:** `{z["isp"]}`
🍉 **» Country:** `{z["country"]}`
🤖 **» @WendiVpn**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        await event.edit(msg,buttons=inline)
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await settings_(event)
    else:
        await event.answer("Access Denied",alert=True)
