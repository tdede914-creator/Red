from kyt import *
from telegram import Button, ReplyKeyboardMarkup
import subprocess

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    inline = [
        [Button.inline("⚡️CREATE ACCOUNT⚡️", "menu")],
        [Button.url("💌TELE GROUP💌", "https://t.me/wendi_vpn"),
         Button.url("☎️ORDER SC☎️", "https://t.me/wendivpn")]
    ]
    
    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except Exception as e:
            print(f"Error answering event: {e}")  # Logging error
            await event.reply("Akses Ditolak")
    elif val == "true":
        try:
            ssh = subprocess.check_output('cat /etc/ssh/.ssh.db | grep "###" | wc -l', shell=True).decode("ascii")
            vms = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode("ascii")
            vls = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode("ascii")
            trj = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode("ascii")
            namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'", shell=True).decode("ascii")
            ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii")
            city = subprocess.check_output("cat /etc/xray/city", shell=True).decode("ascii")
            
            username = sender.username
            user_id = sender.id
            
            keyboard = [['/start', '/menu'], ['/help', '/settings']]
            reply_markup = ReplyKeyboardMarkup(keyboard, one_time_keyboard=True)
            
            msg = f"""
◇━━━━━━━━━━━━━━━━━━━━━━━◇ 
   ⚡️ PREMIUM PANEL MENU ⚡️
◇━━━━━━━━━━━━━━━━━━━━━━━◇ 
»🔰 OS     : {namaos.strip().replace('"','')}
»🔰 CITY   : {city.strip()}
»🔰 DOMAIN : {DOMAIN}
»🔰 IP VPS : {ipsaya.strip()}
◇━━━━━━━━━━━━━━━━━━━━━━━◇
»🆔User ID : {user_id}
»👤Username:@{username}
"""
            x = await event.edit(msg, buttons=inline, reply_markup=reply_markup)
            if not x:
                await event.reply(msg, buttons=inline, reply_markup=reply_markup)
        except Exception as e:
            print(f"Error processing event: {e}")  # Logging error
            await event.reply("Terjadi kesalahan saat memproses permintaan.")